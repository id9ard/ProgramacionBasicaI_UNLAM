package ar.edu.unlam.pb1.dominio;

import java.util.Arrays;

public class Cliente {

	private int dni;
	private String nombre;
	private String contrasenia;
	Actividad[] actividades;

	public Cliente(int dni, String nombre, String contrasenia) {
		// TODO: El cliente podra realizar hasta 10000 actividades
		this.dni = dni;
		this.nombre = nombre;
		this.contrasenia = contrasenia;
		this.actividades = new Actividad[1000];
	}

	public Actividad[] getActividades() {
		return actividades;
	}

	public void setActividades(Actividad[] actividades) {
		this.actividades = actividades;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}

	public void realizarActividad(Actividad actividad) {
		// TODO: Agrega una actividad a las actividades del cliente
		boolean agregado = false;
		int posicion = 0;
		
		while(posicion < this.actividades.length && !agregado) {
			if(this.actividades[posicion] == null) {
				this.actividades[posicion] = actividad;
				agregado = true;
			}
			posicion++;
		}
		
	}

	public boolean eliminarActividadPorId(int id) {
		// TODO: busca una actividad por su id y en caso de existir, la elimina.
		boolean sePudoEliminar = false;
		int posicion = 0;
		
		while(posicion < this.actividades.length && !sePudoEliminar) {
			if(this.actividades[posicion] != null && this.actividades[posicion].getId() == id) {
				this.actividades[posicion] = null;
				sePudoEliminar = true;
			}
			posicion++;
		}
		
		return sePudoEliminar;
	}

	public int obtenerCantidadDeActividadesRealizadas() {
		// TODO: revisar cuantas actividades realizo el cliente y devolver el valor
		// correspondiente
		return 0;
	}

	public double obtenerCantidadDeCaloriasQuemadasPorActividadDeTipo(TipoActividad tipoActividad) {
		// TODO: Obtener la cantidad de calorias quemadas por el cliente al realizar
		// actividades de un tipo determinado
		return 0;
	}

	@Override
	public String toString() {
		return "Cliente [dni=" + dni + ", nombre=" + nombre + ", contrasenia=" + contrasenia + ", actividades="
				+ Arrays.toString(actividades) + "]";
	}
	
}
