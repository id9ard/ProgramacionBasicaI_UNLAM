package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.TipoDePasta;

public class Pasta {

	private String codigo;
	private TipoDePasta tipoDePasta;
	private boolean esRellena;
	private double precio;
	private int cantidad;

	// TODO: Completar constructor/es, getters, setters y otros metodos que
	// considere necesarios.

	public Pasta(String codigo, TipoDePasta tipoDePasta, boolean esRellena, double precio, int cantidadEnStock) {
	}

}
