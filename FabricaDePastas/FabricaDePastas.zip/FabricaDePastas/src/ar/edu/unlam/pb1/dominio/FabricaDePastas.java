package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.TipoDePasta;

public class FabricaDePastas {

	private String nombrePedido;
	private Pasta[] pastas;
	private Pasta[] pedido;

	public FabricaDePastas(String nombrePedido) {
		// TODO: Completar el constructor para que el producto funcione correctamente.
		this.pastas = new Pasta[TipoDePasta.values().length];
		this.inicializarFabricaDePastas();
	}

	// TODO: Completar los getters y setters que considere necesarios.

	public boolean agregarPastaAlPedido(String codigoPasta, int cantidad) {
		// TODO: Se debe buscar la pasta por su codigo y agregarla al pedido solo si hay
		// cantidad suficiente de la pasta solicitada. Luego de agregarla, se debe
		// actualizar la cantidad de la pasta agregada en el array de pastas (considerar
		// el
		// metodo descontarCantidadDePastaDisponible()). Devuelve verdadero en caso de
		// completar la
		// operacion o falso en caso de no poder realizar la operacion por el motivo que
		// sea.
		return false;
	}

	private Pasta obtenerPastaPorCodigo(String codigoPasta) {
		// TODO: Se debe buscar en el array de pastas y devolver la pasta que coincida
		// con el codigoPasta
		// suministrado, o null en caso de que no exista una pasta con ese codigoPasta.
		return null;
	}

	private void descontarCantidadDePastaDisponible(String codigoPasta, int cantidadADescontar) {
		// TODO: Actualiza la cantidad de pasta en el array de pastas.
	}

	public double obtenerTotalDelPedido() {
		// TODO: Calcula y devuelve el total del pedido considerando el precio de la
		// pasta y la cantidad solicitada en el pedido.
		return 0.0;
	}

	public Pasta obtenerPastaDeUnTipoDePastaConMenorCantidadEnElPedido(TipoDePasta tipoDePasta) {
		// TODO: Devuelve la pasta que aplique al tipoDePasta indicado, que posea menor
		// cantidad en el pedido.
		return null;
	}

	public Pasta[] obtenerPedidoPorPrecioDePastaDescendente() {
		// TODO: Debe ordenar y devolver las pastas en el pedido de manera descendente,
		// debiendo quedar en la primera posicion la pasta de mayor precio.
		return null;
	}

	private Pasta agregarPasta(String codigo, TipoDePasta tipoDePasta, boolean esRellena, double precio,
			int cantidadEnStock) {
		return new Pasta(codigo, tipoDePasta, esRellena, precio, cantidadEnStock);
	}

	private void inicializarFabricaDePastas() {
		int codigo = 100;
		for (int i = 0; i < TipoDePasta.values().length; i++) {

			this.pastas[i] = this.agregarPasta("" + codigo, TipoDePasta.values()[i], i != 0, ((i * 7) + 115.5),
					(i * 7 + 15));
			codigo += 100;
		}

	}
}
