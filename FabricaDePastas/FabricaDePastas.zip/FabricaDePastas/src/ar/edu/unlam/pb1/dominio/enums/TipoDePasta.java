package ar.edu.unlam.pb1.dominio.enums;

public enum TipoDePasta {
	FIDEOS, RAVIOLES, AGNOLOTIS, CAPELETIS, CANELONES
}
