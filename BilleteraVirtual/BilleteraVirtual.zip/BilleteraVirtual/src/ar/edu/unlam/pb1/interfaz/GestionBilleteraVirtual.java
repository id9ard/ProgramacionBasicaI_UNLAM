package ar.edu.unlam.pb1.interfaz;

import java.util.Scanner;

import ar.edu.unlam.pb1.dominio.BilleteraVirtual;
import ar.edu.unlam.pb1.dominio.Operacion;
import ar.edu.unlam.pb1.dominio.Usuario;
import ar.edu.unlam.pb1.dominio.enums.Monedas;
import ar.edu.unlam.pb1.interfaz.enums.MenuPrincipal;

public class GestionBilleteraVirtual {

	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {

		boolean sesionInciada = false;
		BilleteraVirtual billeteraVirtual = new BilleteraVirtual();
		registrarUsuario(billeteraVirtual);

		do {
			sesionInciada = iniciarSesion(billeteraVirtual);

		} while (!sesionInciada);

		MenuPrincipal opcion = null;

		do {

			mostrarMenuPrincipal();
			opcion = ingresarOpcionDelMenuPrincipalValidada();

			switch (opcion) {
			case COMPRAR_MONEDA:
				comprarMoneda(billeteraVirtual);
				break;
			case VENDER_MONEDA:
				venderMoneda(billeteraVirtual);
				break;
			case MOSTRAR_OPERACION_MAYOR_CANTIDAD_POR_TIPO_DE_OPERACION:
				mostrarOperacionMayorCantidadPorTipoDeOperacion(billeteraVirtual);
				break;
			case MOSTRAR_OPERACIONES_POR_MONEDA:
				mostrarOperacionesPorMoneda(billeteraVirtual);
				break;
			case MOSTRAR_OEPRACION_POR_ID:
				mostrarOperacionPorId(billeteraVirtual);
				break;
			case SALIR:
				mostrarOperacionesTotales(billeteraVirtual);
				mostrarPorPantalla("\nHasta luego!");
				break;
			}

		} while (opcion != MenuPrincipal.SALIR);
	}

	private static void mostrarOperacionesTotales(BilleteraVirtual billeteraVirtual) {
		Operacion[] operacionesOrdenadas = billeteraVirtual.getOperaciones();
		mostrarOperaciones(operacionesOrdenadas);
	}

	private static void registrarUsuario(BilleteraVirtual billeteraVirtual) {
		Usuario usuario = new Usuario(ingresarLong("\nIngrese DNI: "), ingresarString("\nIngresar contrasenia"));
		billeteraVirtual.registrarUsuario(usuario);
		mostrarPorPantalla("\nUsuario registrado!");
	}

	private static void comprarMoneda(BilleteraVirtual billeteraVirtual) {
		// TODO: Se debe ingresar la moneda (ver ingresarMoneda()) y la cantidad a
		// comprar, debiendo validar que la cantidad sea positiva.
		// Se debe registrar la operacion en la billetera, si es existoso, mostrar un
		// mensaje apropiado. Si no fue posible registrar, mostrar un mensaje de error.
		Monedas moneda = ingresarMoneda();
		int cantidad;
		
		do {
			
			cantidad = ingresarEntero("Ingresar la cantidad a comprar :");
			
		}while(cantidad < 1);
		
		boolean sePudoComprar = billeteraVirtual.registrarOperacion(moneda, cantidad, 'c');
		
		if(sePudoComprar) {
			mostrarPorPantalla("Se pudo ingresar operacion");
		} else {
			mostrarPorPantalla("No se pudo ingresar operacion!");
		}
		
	}

	private static void venderMoneda(BilleteraVirtual billeteraVirtual) {
		// TODO: Se debe ingresar la moneda (ver ingresarMoneda()) y la cantidad a
		// vender. La cantidad no puede ser negativa.
		// Se debera verificar que la billetera tiene cantidad de dicha moneda
		// suficiente para vender. Si poseemos esa cantidad en la billetera, se procede
		// a registrar la operacion de venta debiendo mostrar un mensaje de exito, caso
		// contrario, mostrar un menasje de error.
		
		Monedas moneda = ingresarMoneda();
		int cantidadAVender;
		
		do {
			
			cantidadAVender = ingresarEntero("Ingresar la cantidad a vender :");
			
		}while(cantidadAVender < 1);
		
		boolean sePuedeVender = billeteraVirtual.hayCantidadDeMonedaSuficiente(moneda, cantidadAVender);
		
		if(sePuedeVender) {
			mostrarPorPantalla("Se pudo vender");
		} else {
			mostrarPorPantalla("No se pudo vender!");
		}
			
		
	}

	private static void mostrarOperacionMayorCantidadPorTipoDeOperacion(BilleteraVirtual billeteraVirtual) {
		// TODO: Se debe ingresar el tipoDeOperacion ('c' -> compra o 'v' -> venta),
		// obtener la operacion de mayor cantidad por el tipoDeOperacion ingresado y
		// mostrar la operacion, si es que existe. Caso contrario mostrar un mensaje
		// apropiado.
		char tipoOperacion = ingresarChar("Ingresar tipo de operacion :");
		Operacion operacionMayorPorTipoDeOperacion = billeteraVirtual.obtenerOperacionMayorCantidadPorTipoDeOperacion(tipoOperacion);
		
		if(operacionMayorPorTipoDeOperacion != null) {
			System.out.println(operacionMayorPorTipoDeOperacion);
		} else {
			mostrarPorPantalla("No existen operaciones!");
		}
		
	}

	private static void mostrarOperacionesPorMoneda(BilleteraVirtual billeteraVirtual) {
		// TODO: Se debe ingresar la moneda para obtener las operacion de dicha moneda y
		// mostrarlas.
		
		Monedas monedas = ingresarMoneda();
		Operacion[] operaciones = billeteraVirtual.obtenerOperacionesPorMoneda(monedas);
		mostrarOperaciones(operaciones);
		
	}

	private static void mostrarOperacionPorId(BilleteraVirtual billeteraVirtual) {
		// TODO: Se debe ingresar el id de la operacion a mostrar, obtener la operacion
		// desde la billetera y si se encuentra, mostrarla, caso contrario mostrar un
		// mensaje apropiado.
		int id = ingresarEntero("Ingresar id :");
		
		Operacion operacion = billeteraVirtual.obtenerPorId(id);
		
		if(operacion != null) {
			System.out.println(operacion);
		} else {
			mostrarPorPantalla("No existe el id!");
		}
		
	}

	private static MenuPrincipal ingresarOpcionDelMenuPrincipalValidada() {
		// TODO: Se debe ingresar una opcion debiendo validar que exista dentro del
		// MenuPrincipal para luego devolver la opcion del MenuPrincipal.
		MenuPrincipal opcionMenu = null;
		int opcionUsuario;
		
		do {
			
			opcionUsuario = ingresarEntero("Ingresar opcion del menu :");
			
		}while(opcionUsuario < 1 || opcionUsuario > MenuPrincipal.values().length);
		
		return opcionMenu.values()[opcionUsuario - 1];
	}

	private static void mostrarMenuPrincipal() {
		String menu = "\n*****Menu Billetera virtual*****\n";
		for (int i = 0; i < MenuPrincipal.values().length; i++) {
			menu += (i + 1) + ". " + MenuPrincipal.values()[i].getDescripcion() + "\n";
		}
		mostrarPorPantalla(menu);
	}

	private static void mostrarPorPantalla(String mensaje) {
		System.out.println(mensaje);
	}

	private static boolean iniciarSesion(BilleteraVirtual billeteraVirtual) {
		long dni = ingresarEntero("\nIngrese el DNI:");
		String contrasenia = ingresarString("\nIngrese la contrasenia:");
		return billeteraVirtual.iniciarSesion(dni, contrasenia);
	}

	private static char ingresarChar(String mensaje) {
		mostrarPorPantalla(mensaje);
		return teclado.next().charAt(0);
	}

	private static int ingresarEntero(String mensaje) {
		mostrarPorPantalla(mensaje);
		return teclado.nextInt();
	}

	private static long ingresarLong(String mensaje) {
		mostrarPorPantalla(mensaje);
		return teclado.nextLong();
	}

	private static double ingresarDouble(String mensaje) {
		mostrarPorPantalla(mensaje);
		return teclado.nextDouble();
	}

	private static String ingresarString(String mensaje) {
		mostrarPorPantalla(mensaje);
		return teclado.next();
	}

	private static Monedas ingresarMoneda() {
		mostrarMonedas();
		String monedaIngresada = ingresarString("\nIngrese el texto de la moneda").toUpperCase();
		return Monedas.valueOf(monedaIngresada);
	}

	private static void mostrarMonedas() {
		String monedas = "\n*****Monedas*****\n";
		for (int i = 0; i < Monedas.values().length; i++) {
			monedas += Monedas.values()[i] + "\n";
		}
		mostrarPorPantalla("\n" + monedas);
	}

	private static void mostrarOperaciones(Operacion[] operaciones) {

		for (int i = 0; i < operaciones.length; i++) {
			if (operaciones[i] != null) {
				mostrarPorPantalla("\n" + operaciones[i].toString());
			}

		}
	}
}
