package ar.edu.unlam.pb1.dominio.enums;

public enum Monedas {
	BITCOIN, ETHEREUM, PAX
}
