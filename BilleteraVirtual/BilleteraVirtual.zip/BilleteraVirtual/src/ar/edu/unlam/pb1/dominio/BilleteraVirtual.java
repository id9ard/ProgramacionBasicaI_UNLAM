package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.Monedas;

public class BilleteraVirtual {

	private static long siguienteId;
	private Usuario usuario;
	private Operacion[] operaciones;

	public BilleteraVirtual() {
		// TODO: Completar el constructor para que el producto funcione correctamente.
		//this.registrarUsuario(usuario);
		this.operaciones = new Operacion[10];
	}

	public void registrarUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public boolean iniciarSesion(long dni, String contrasenia) {
		// TODO: Debe verificar que el dni y la contrasenia suministrados coincidan con
		// la del usuario
		boolean estaVerificado = false;
		
		if(usuario.getDni() == dni && usuario.getContrasenia().equals(contrasenia)) {
			estaVerificado = true;
		}
		
		return estaVerificado ;
	}

	public Operacion obtenerPorId(long id) {
		// TODO: Debe obtener una operacion por su id, en caso de no encontrarla debe
		// devolver null
		Operacion operacionObtenida = null;
		boolean encontrado = false;
		int posicion = 0;
		
		while(posicion < this.operaciones.length && !encontrado) {
			if(this.operaciones[posicion] != null && this.operaciones[posicion].getId() == id) {
				operacionObtenida = this.operaciones[posicion];
				encontrado = true;
			}
			posicion++;
		}
		
		return operacionObtenida;
	}

	public Operacion[] obtenerOperacionesPorMoneda(Monedas moneda) {
		// TODO: Debe devolver un array de operaciones que cumplan con la moneda
		// suministrada. Dicho array debe estar ordenado por id operacion descendente.
		Operacion[] operacionesObtenidas = new Operacion[this.operaciones.length];
		int posicion = 0;
		
		for(int i = 0; i < this.operaciones.length ;i++) {
			if(this.operaciones[i] != null && this.operaciones[i].getMoneda().equals(moneda)) {
				operacionesObtenidas[posicion++] = this.operaciones[i];
			}
		}
		
		return operacionesObtenidas;
	}

	public Operacion obtenerOperacionMayorCantidadPorTipoDeOperacion(char tipoDeOperacion) {
		// TODO: Debe obtener la operacion de mayor cantidad que cumpla con el tipo de
		// operacion suministrado. Si no existe alguna operacion para ese
		// tipoDeOperacion debe devolver null.
		Operacion operacionObtenidaMayorCantidad = null;
		
		for(int i= 0; i <this.operaciones.length ;i++) {
			if(this.operaciones[i] != null && this.operaciones[i].getTipoDeOperacion() == tipoDeOperacion) {
				if(operacionObtenidaMayorCantidad == null || this.operaciones[i].getCantidad() > operacionObtenidaMayorCantidad.getCantidad()) {
					operacionObtenidaMayorCantidad = this.operaciones[i];
				}
			}
		}
		
		return operacionObtenidaMayorCantidad;
	}

	public boolean hayCantidadDeMonedaSuficiente(Monedas moneda, double cantidadAVender) {
		// TODO: Debe devolver verdadero si la cantidad de moneda es suficiente respecto
		// la cantidadAVender suministrada.
		// Para calcular la cantidad, se debera revisar el array de operaciones y
		// acumular segun la moneda y el tipoDeOperacion, si es de compra ('c') se debe
		// agregar la cantidad de la operacion a un acumulador, en caso de venta ('v'),
		// se debe restar la cantidad de la operacion al acumulador.
		// Devuelve verdadero si la cantidad acumulada satisface la cantidadAVender.
		boolean hayCantidadSuficiente = false;
		int cantidadDisponibleAVender = 0;
		
		for(int i = 0; i < this.operaciones.length ;i++) {
			if(this.operaciones[i] != null) {
				if(this.operaciones[i].getMoneda().equals(moneda) && this.operaciones[i].getTipoDeOperacion() == 'c') {
					cantidadDisponibleAVender += this.operaciones[i].getCantidad();
				} if(this.operaciones[i].getMoneda().equals(moneda) && this.operaciones[i].getTipoDeOperacion() == 'v') {
					cantidadDisponibleAVender -= this.operaciones[i].getCantidad();
				}
			}
		}
		
		if(cantidadDisponibleAVender >= cantidadAVender) {
			this.registrarOperacion(moneda, cantidadAVender, 'v');
			hayCantidadSuficiente = true;
		}
		
		return hayCantidadSuficiente;
	}

	public boolean registrarOperacion(Monedas moneda, double cantidad, char tipoOperacion) {
		// TODO: Se debera instanciar una operacion y agregarla al array de operaciones.
		boolean sePudoRegistrar = false;
		int posicion = 0;
		
		while(posicion < this.operaciones.length && !sePudoRegistrar) {
			if(this.operaciones[posicion] == null) {
				this.operaciones[posicion] = new Operacion(
						BilleteraVirtual.getSiguienteId(), 
						tipoOperacion, 
						moneda, 
						obtenerPrecioDeMoneda(moneda), 
						cantidad);
					sePudoRegistrar = true; 
			}
			posicion++;
		}
		
		return sePudoRegistrar;
	}

	private Operacion[] ordenarOperacionesPorIdDescendente(Operacion[] operaciones) {
		// TODO: Debe ordenar el array suministrado de manera descendete por el id de
		// operacion y devolverlo.
		Operacion[] operacionesOrdenadas = operaciones;
	 	Operacion aux;
		
	 	for(int i= 0; i < (operacionesOrdenadas.length - 1) ;i++) {
	 		for(int j= 0; j < (operacionesOrdenadas.length - i - 1) ;j++) {
	 			if(operacionesOrdenadas[j] != null && operacionesOrdenadas[j+1] != null) {
	 				if(operacionesOrdenadas[j].getId() < operacionesOrdenadas[j+1].getId()) {
	 					aux = operacionesOrdenadas[j];
	 					operacionesOrdenadas[j] = operacionesOrdenadas[j+1];
	 					operacionesOrdenadas[j+1] = aux;
	 				}
	 			}
	 		}
	 	}
		
		return operacionesOrdenadas;
	}

	private double obtenerPrecioDeMoneda(Monedas moneda) {
		double precio = 0.0;

		switch (moneda) {
		case BITCOIN:
			precio = 67668.01;
			break;
		case ETHEREUM:
			precio = 3500.8;
			break;
		case PAX:
			precio = 2311;
			break;
		}

		return precio;
	}

	public static long getSiguienteId() {
		return ++siguienteId;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public Operacion[] getOperaciones() {
		return this.ordenarOperacionesPorIdDescendente(operaciones);
	}
	
}
