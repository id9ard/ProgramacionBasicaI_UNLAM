package ar.edu.unlam.pb1.dominio.enums;

public enum TipoDePintura {
	SATINADA, MATE
}
