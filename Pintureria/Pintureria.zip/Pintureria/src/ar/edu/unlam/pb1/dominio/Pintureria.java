package ar.edu.unlam.pb1.dominio;

import java.util.Arrays;

import ar.edu.unlam.pb1.dominio.enums.TipoDePintura;

public class Pintureria {
	
	// TODO: Completar getters, setters, constructor y metodos necesarios para garantizar el correcto funcionamiento.

	private String nombre;
	private LataDePintura[] latasDePintura;
	private double saldo;
	private int cantidadLatasVendidas;

	public Pintureria(String nombre, int cantidadLatasPintura, double saldo) {
		this.nombre = nombre;
		this.latasDePintura = new LataDePintura[cantidadLatasPintura];
		this.saldo = saldo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public LataDePintura[] getLatasDePintura() {
		return latasDePintura;
	}

	public void setLatasDePintura(LataDePintura[] latasDePintura) {
		this.latasDePintura = latasDePintura;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public int getCantidadLatasVendidas() {
		return cantidadLatasVendidas;
	}

	public void setCantidadLatasVendidas(int cantidadLatasVendidas) {
		this.cantidadLatasVendidas = cantidadLatasVendidas;
	}

	public LataDePintura obtenerLataDePinturaPorCodigo(int codigo) {
		// TODO: Se debe buscar una lata de pintura por codigo entre las latas de
		// pintura que tiene la pintureria y devolverla. En caso de no existir alguna
		// que cumpla con el codigo, devolver null.
		LataDePintura lataDePintura = null;
		int posicion = 0;
		boolean encontrada = false;
		
		while(posicion < this.latasDePintura.length && !encontrada) {
			if(this.latasDePintura[posicion] != null && this.latasDePintura[posicion].getCodigo() == codigo) {
				lataDePintura = this.latasDePintura[posicion];
				encontrada = true;
			}
			posicion++;
		}
		
		return lataDePintura;
	}

	public boolean agregarLataDePintura(int codigo, String nombre, double porcentajeGanancia,
			TipoDePintura tipoDePintura, int stock) {
		// TODO: Se debera instanciar una lata de pintura y agregarla al array de latas
		// de pintura.
		boolean agregada = false;
		int posicion = 0;
		
		while(posicion < this.latasDePintura.length && !agregada) {
			if(this.latasDePintura[posicion] == null) {
				this.latasDePintura[posicion] = new LataDePintura(codigo, nombre, porcentajeGanancia, tipoDePintura, stock);
				agregada = true;
			}
			posicion++;
		}
		
		return agregada;
	}

	public boolean hayStock(int codigo, int cantidadDeLatas) {
		// TODO: Se debera verificar si la pintureria cuenta con stock suficiente segun
		// el codigo de la lata de pintura solicitado. Se debe devolver verdadero en
		// caso de que el stock de la lata de pintura (que cumpla con el codigo), sea
		// mayor o igual a la cantidadDeLatas deseada.
		boolean hayLatasDisponibles = false; 
		LataDePintura lataDePintura = this.obtenerLataDePinturaPorCodigo(codigo);
		
		if(lataDePintura != null && lataDePintura.getStock() >= cantidadDeLatas) {
			hayLatasDisponibles = true;
		}
		
		return hayLatasDisponibles;
	}

	public void venderLatasDePintura(int codigo, int cantidadDeLatas) {
		// TODO: Se debera actualizar el stock de la lata de pintura, debiendo buscarla
		// por codigo, y luego restando la cantidad de latas a vender, al stock actual
		// de la lata de pintura.
		// Tambien es necesario contabilizar cuantas latas se vendieron y acumular el
		// precio total (precio de la lata por cantidad a vender) al saldo de la
		// pintureria.
		LataDePintura lataDePintura = this.obtenerLataDePinturaPorCodigo(codigo);
		boolean hayStock = this.hayStock(codigo, cantidadDeLatas);
		
		if(lataDePintura != null && hayStock) {
			lataDePintura.setStock(lataDePintura.getStock() - cantidadDeLatas);
			this.setCantidadLatasVendidas(this.getCantidadLatasVendidas() + cantidadDeLatas);
			this.setSaldo(this.getSaldo() + (lataDePintura.obtenerPrecio() * cantidadDeLatas));
		}
	}

	public int obtenerCantidadDeLatasDePinturasEnStockPorTipo(TipoDePintura tipoDePintura) {
		// TODO: Se debera obtener el numero (cantidad) de latas de pintura en stock
		// (considerando el stock de cada lata de pintura) que sean del tipo de pintura
		// especificado.
		return 0;
	}

	public LataDePintura obtenerLataDePinturaMasBarataPorTipo(TipoDePintura tipoDePintura) {
		// TODO: Se debera obtener la lata de pintura mas barata que aplique al tipo de
		// pintura especificado.

		return null;
	}

	public LataDePintura[] obtenerLatasDePinturaOrdenadasPorNombreAscendente() {
		// TODO: Se debera devolver un array de latas de pintura ordenados por el nombre
		// de la lata de pintura de manera ascendente.
		// Ejemplo: nombre "Azul" antes que "Rojo".
		LataDePintura[] latasDePinturaObtenidas = this.latasDePintura;
		LataDePintura aux;
		
		for(int i=0; i < (latasDePinturaObtenidas.length - 1) ;i++) {
			for(int j=0; j < (latasDePinturaObtenidas.length - i - 1) ;j++) {
				if(latasDePinturaObtenidas[j] != null && latasDePinturaObtenidas[j+1] != null) {
					if(latasDePinturaObtenidas[j].getNombre().compareTo(latasDePinturaObtenidas[j+1].getNombre()) > 0) {
						aux = latasDePinturaObtenidas[j];
						latasDePinturaObtenidas[j] = latasDePinturaObtenidas[j+1];
						latasDePinturaObtenidas[j+1] = aux;
					}
				}
			}
		}
		
		return latasDePinturaObtenidas;
	}

	@Override
	public String toString() {
		return "Pintureria [saldo=" + saldo + ", cantidadLatasVendidas=" + cantidadLatasVendidas + "]";
	}
	
}
