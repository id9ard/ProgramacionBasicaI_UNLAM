package ar.edu.unlam.pb1.dominio;

public enum TipoDePlanta {
	HIERBA, MATA, ARBUSTO, ARBOL
}
