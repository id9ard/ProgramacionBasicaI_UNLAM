package ar.edu.unlam.pb1.dominio.enums;

public enum Materiales {
	PLASTICO, YESO, RESINA
}
