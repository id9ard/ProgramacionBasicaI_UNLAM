package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.Materiales;

public class FabricaDeCopasDelMundo {

	public static final int MAXIMA_CAPACIDAD_DE_PRODUCCION_DE_COPAS_DEL_MUNDO = 5;

	private static int proximoId = 0;
	private String nombre;
	private CopaDelMundo[] copasDelMundo;

	public FabricaDeCopasDelMundo(String nombreDeFabrica) {
		this.nombre = nombreDeFabrica;
		this.copasDelMundo = new CopaDelMundo[MAXIMA_CAPACIDAD_DE_PRODUCCION_DE_COPAS_DEL_MUNDO];
		// TODO: Completar el constructor para que el producto funcione correctamente.
	}

	public static int getProximoId() {
		return proximoId;
	}

	public static void setProximoId(int proximoId) {
		FabricaDeCopasDelMundo.proximoId = proximoId;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public CopaDelMundo[] getCopasDelMundo() {
		return copasDelMundo;
	}

	public void setCopasDelMundo(CopaDelMundo[] copasDelMundo) {
		this.copasDelMundo = copasDelMundo;
	}

	private static int obtenerProximoId() {
		return ++proximoId;
	}

	public boolean agregarCopaDelMundo(CopaDelMundo copaDelMundo) {
		// TODO: Se debe buscar en el array de copas del mundo por material para saber
		// si ya contamos con copas del mundo de dicho material en stock (considerar el
		// metodo buscarCopaDelMundoPorMaterial()). Si NO tenemos copas del mundo de
		// dicho material en stock, se debe agregar la copa del mundo
		// al array de copas del mundo asignando un nuevo id (considerar el metodo
		// obtenerProximoId()).
		// Si EXISTE una copa del mundo que cumpla con el material, se debe actualizar
		// el stock de la copa del mundo. En caso de actualizar el stock, se debe
		// devolver verdadero.
		boolean sePudoAgregar = false;
		CopaDelMundo buscarCopaDelMundo = this.buscarCopaDelMundoPorMaterial(copaDelMundo.getMaterial());
		int contadorCopasDelMundo = 0;
		int capacidadDisponible = MAXIMA_CAPACIDAD_DE_PRODUCCION_DE_COPAS_DEL_MUNDO - contadorCopasDelMundo;

		for (int i = 0; i < this.copasDelMundo.length; i++) {
			if (this.copasDelMundo[i] != null) {
				contadorCopasDelMundo += this.copasDelMundo[i].getStock();
			}
		}

		if (contadorCopasDelMundo < MAXIMA_CAPACIDAD_DE_PRODUCCION_DE_COPAS_DEL_MUNDO || capacidadDisponible == copaDelMundo.getStock() ) {
			if (buscarCopaDelMundo == null) {
				int posicion = 0;

				while (posicion < this.copasDelMundo.length && !sePudoAgregar) {
					if (this.copasDelMundo[posicion] == null) {
						this.copasDelMundo[posicion] = copaDelMundo;
						this.copasDelMundo[posicion].setId(obtenerProximoId());
						sePudoAgregar = true;
					}
					posicion++;
				}

			} else {
				actualizarStockDeCopaDelMundo(buscarCopaDelMundo, copaDelMundo.getStock());
				sePudoAgregar = true;
			}
		}

		return sePudoAgregar;
	}

	private void actualizarStockDeCopaDelMundo(CopaDelMundo copaDelMundo, int stockAAgregar) {
		// TODO: agregar el stock que llega como parametro, al stock existente de la
		// copa del mundo que llega como parametro.
		copaDelMundo.setStock(copaDelMundo.getStock() + stockAAgregar);
	}

	private CopaDelMundo buscarCopaDelMundoPorMaterial(Materiales material) {
		// TODO: Se debe buscar una copa del mundo por material en el array de copas del
		// mundo y devolverla. En caso de no poseer una copa del mundo que cumpla con el
		// material, se debe devovler null.
		CopaDelMundo buscarCopaDelMundo = null;
		int posicion = 0;
		
		while(posicion < this.copasDelMundo.length && buscarCopaDelMundo == null) {
			if(this.copasDelMundo[posicion] != null && this.copasDelMundo[posicion].getMaterial().equals(material)) {
				buscarCopaDelMundo = this.copasDelMundo[posicion];
			}
			posicion++;
		}
		
		return buscarCopaDelMundo;
	}

	public double obtenerPromedioDePreciosDeCopasDelMundo() {
		// TODO: Se debe calcular y devolver el promedio de precios de todas las copas
		// del mundo sin considerar el stock de cada una.
		double promedio = 0;
		int sumatoriaDePrecios = 0;
		int contador = 0;
		
		for(int i= 0; i < this.copasDelMundo.length ; i++) {
			if(this.copasDelMundo[i] != null) {
				sumatoriaDePrecios += this.copasDelMundo[i].getPrecio();
				contador++;
			}
		}
		
		if(contador > 0) {
			promedio = sumatoriaDePrecios / contador;
		}
		
		return promedio;
	}

	public CopaDelMundo[] obtenerCopasDelMundoQueNoSonDeUnMaterial(Materiales material) {
		// TODO: Se debe generar y devolver un nuevo array de copas del mundo que contenga las
		// copas del mundo que NO apliquen al material que llega como parametro.
		CopaDelMundo[] copaDelMundoQueNoSonDeUnMayerial = new CopaDelMundo[this.copasDelMundo.length];
		int posicion = 0;
		
		for(int i= 0; i < this.copasDelMundo.length ; i++) {
			if(this.copasDelMundo[i] != null && !this.copasDelMundo[i].getMaterial().equals(material)) {
				copaDelMundoQueNoSonDeUnMayerial[posicion++] = this.copasDelMundo[i];
			}
		}
		
		return copaDelMundoQueNoSonDeUnMayerial;
	}

	public CopaDelMundo[] obtenerCopasDelMundoOrdenadasPorStockAscendente() {
		// TODO: Se debe ordenar y devolver el array de copas del mundo ordenandolas por
		// stock ascendente.
		CopaDelMundo[] copaDelMundoPorStockOrdenadas = this.copasDelMundo;
		CopaDelMundo aux;
		
		for(int i= 0; i < (copaDelMundoPorStockOrdenadas.length - 1); i++) {
			for(int j= 0; j < (copaDelMundoPorStockOrdenadas.length - i - 1); j++) {
				if(copaDelMundoPorStockOrdenadas[j] != null && copaDelMundoPorStockOrdenadas[j+1] != null) {
					if(copaDelMundoPorStockOrdenadas[j].getStock() > copaDelMundoPorStockOrdenadas[j+1].getStock()) {
						aux = copaDelMundoPorStockOrdenadas[j];
						copaDelMundoPorStockOrdenadas[j] = copaDelMundoPorStockOrdenadas[j+1];
						copaDelMundoPorStockOrdenadas[j+1] = aux;
					}
				}
			}
		}
		
		return copaDelMundoPorStockOrdenadas;
	}

}
