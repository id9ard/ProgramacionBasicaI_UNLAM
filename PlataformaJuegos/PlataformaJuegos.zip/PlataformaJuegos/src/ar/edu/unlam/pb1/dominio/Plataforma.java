package ar.edu.unlam.pb1.dominio;

public class Plataforma {

	private Usuario[] usuarios;
	private Juego[] juegos;

	public Plataforma() {
		this.usuarios = new Usuario[1000];
		this.juegos = new Juego[10];
		this.inicializarPlataforma(); // :)
	}
	
	public Juego[] getJuegos() {
		return this.juegos;
	}

	public Usuario buscarUsuarioConCorreo(String correo) {
		// TODO:Busca un usuario entre los usuarios de la plataforma que tenga el correo
		// suministrado.
		// Si encuentra un usuario con ese correo, lo deuelve. Si NO encuentra un
		// usuario con ese correo, entonces devuelve null.
		Usuario usuario = null;
		int posicion = 0;
		
		while(posicion < this.usuarios.length && usuario == null) {
			if(this.usuarios[posicion] != null && this.usuarios[posicion].getCorreo().equals(correo)) {
				usuario = this.usuarios[posicion];
			}
			posicion++;
		}
		
		return usuario;
	}

	public Usuario iniciarSesion(String correo, String contrasenia) {
		// TODO: Obtiene un usuario buscandolo por su correo.
		// Si existe, verifica que la contrasenia sea correcta. Si asi es, devuelve el
		// usuario.
		// Si ningun usuario tiene ese correo o la contrasenia no coincide, debe devolver null
		Usuario usuario = null;
		int posicion = 0;
		
		while(posicion < this.usuarios.length && usuario == null) {
			if(this.usuarios[posicion] != null) {
				if(this.usuarios[posicion].getCorreo().equals(correo) && this.usuarios[posicion].getContrasenia().equals(contrasenia)) {
					usuario = this.usuarios[posicion];
				}
			}
			posicion++;
		}
		
		return usuario;
	}

	public boolean esValidoEl(String correo) {
		// TODO: Validar el correo. Para que el correo sea valido, tiene que tener un caracter arroba ('@') y terminar en ".com"
		boolean esValidoElCorreo = false;
		
		if(correo.contains("@") && correo.endsWith(".com")) {
			esValidoElCorreo = true;
		}
		
		return esValidoElCorreo;
	}

	public boolean registrarUsuario(Usuario usuario) {
		// TODO: Agregar un usuario a la plataforma.
		// En caso de exito, devuelve verdadero
		boolean sePudoRegistrar = false;
		int posicion = 0;
		
		while(posicion < this.usuarios.length && !sePudoRegistrar) {
			if(this.usuarios[posicion] == null) {
				this.usuarios[posicion] = usuario;
				sePudoRegistrar = true;
			}
			posicion++;
		}
		
		return sePudoRegistrar;
	}

	public Juego obtenerJuegoPorSuId(int id) {
		// Busca entre los juegos de la plataforma si alguno tiene el id suministrado.
		// Si hay un juego con ese id, se devuelve el juego, caso contrario, se devuelve null
		Juego juego = null;
		int posicion = 0;
		
		while(posicion < this.juegos.length && juego == null) {
			if(this.juegos[posicion] != null && this.juegos[posicion].getId() == id) {
				juego = this.juegos[posicion];
			}
			posicion++;
		}
		
		return juego;
	}

	private Juego crearJuego(int id, String nombre, Categoria categoria) {
		return new Juego(id, nombre + " " + id, categoria);
	}

	private void inicializarPlataforma() {

		String nombre = "";
		Categoria categoria;

		for (int i = 0; i < this.juegos.length; i++) {

			if (i < 3) {
				nombre = "Aventura";
				categoria = Categoria.AVENTURA;
			} else if (i < 7) {
				nombre = "Accion";
				categoria = Categoria.ACCION;
			} else {
				nombre = "Deportes";
				categoria = Categoria.DEPORTES;
			}

			this.juegos[i] = crearJuego((i + 1), nombre, categoria);
		}

	}

}
