package ar.edu.unlam.pb1.dominio;

public enum Categoria {
	AVENTURA, ACCION, DEPORTES
}
