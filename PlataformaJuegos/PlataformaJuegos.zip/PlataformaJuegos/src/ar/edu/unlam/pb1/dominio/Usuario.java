package ar.edu.unlam.pb1.dominio;

import java.util.Arrays;

public class Usuario {

	private String nombre;
	private String apellido;
	private String correo;
	private String contrasenia;
	private Juego[] juegos;

	public Usuario(String nombre, String apellido, String correo, String contrasenia) {
		// Daremos un espacio de 1000 juegos a cada nuevo usuario
		this.nombre = nombre;
		this.apellido = apellido;
		this.correo = correo;
		this.contrasenia = contrasenia;
		this.juegos = new Juego[1000];
	}

	public boolean agregarAMisJuegos(Juego juego) {
		// TODO: Verificar no tener el juego adquirido
		// En caso de no tenerlo, se agrega a juegos. Ver el metodo tengoElJuegoDe()
		boolean sePudoAgregarJuego = false;
		boolean tengoEljuegoDe = this.tengoElJuegoDe(juego.getId());

		if (!tengoEljuegoDe) {
			int posicion = 0;
			boolean sePudoAgregaralArray = false;

			while (posicion < this.juegos.length && !sePudoAgregaralArray) {
				if (this.juegos[posicion] == null) {
					this.juegos[posicion] = juego;
					sePudoAgregaralArray = true;
					sePudoAgregarJuego = true;
				}
				posicion++;
			}
		}

		return sePudoAgregarJuego;
	}

	public boolean tengoElJuegoDe(int id) {
		// TODO: Verifica si tengo un juego con el id suministrado en mis juegos
		// Devuelve verdadero en caso de poseer el juego.
		boolean tengoElJuego = false;
		int posicion = 0;
		
		while(posicion < this.juegos.length && !tengoElJuego) {
			if(this.juegos[posicion] != null && this.juegos[posicion].getId() == id) {
				tengoElJuego = true;
			}
			posicion++;
		}
		
		
		return tengoElJuego;
	}

	public Juego obtenerJuegoMasJugadoPorCategoria(Categoria categoria) {
		// TODO: Revisa los juegos que cumplen con la categoria suministrada y obtiene el
		// juego mas jugado de dicha categoria
		// Si no existe un juego para esa categoria, devuelve null
		Juego juegoMasJugado = null;
		int posicion = 0;
		
		while(posicion < this.juegos.length && juegoMasJugado == null) {
			if (this.juegos[posicion] != null && this.juegos[posicion].getCategoria().equals(categoria)) {
				if(juegoMasJugado == null || this.juegos[posicion].getCantidadHorasJugadas() > juegoMasJugado.getCantidadHorasJugadas()) {
					juegoMasJugado = this.juegos[posicion];
				}
			}
			posicion++;
		}
		
		return juegoMasJugado;
	}

	public Juego[] obtenerJuegosOrdenadosPorCategoria() {
		// TODO: Obtiene los juegos del usuario ordenados por categoria.
		// Investigar compareTo()
		Juego[] juegosOrdenados = this.juegos;
		Juego aux;
		
		for(int i= 0; i < (this.juegos.length - 1) ; i++) {
			for(int j= 0; j < (this.juegos.length - i - 1) ; j++) {
				if(juegosOrdenados[j] != null && juegosOrdenados[j+1] != null) {
					if(juegosOrdenados[j].getCategoria().compareTo(juegosOrdenados[j+1].getCategoria()) > 0) {
						aux = juegosOrdenados[j];
						juegosOrdenados[j+1] = juegosOrdenados[j];
						juegosOrdenados[j] = aux;
					}
				}
			}
		}
		
		return juegos;
	}

	public void jugarAlJuegoDe(int id) {
		// TODO: Revisa entre los juegos si alguno tiene el id suministrado. 
		// Si lo encuentra, le agrega 1 hora y media (1.5) a la cantidad de horas jugadas.
		// Siempre deberia encontrar el juego con el id que llega como parametro
		
		boolean juegoEncontrado = false;
		int posicion = 0;

		while (posicion < this.juegos.length && !juegoEncontrado) {
			if (this.juegos[posicion] != null && this.juegos[posicion].getId() == id) {
				this.juegos[posicion].setCantidadHorasJugadas(this.juegos[posicion].getCantidadHorasJugadas() + 1.5);
				juegoEncontrado = true;
			}
			posicion++;
		}

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}

	public Juego[] getJuegos() {
		return juegos;
	}

	public void setJuegos(Juego[] juegos) {
		this.juegos = juegos;
	}

	@Override
	public String toString() {
		return "Usuario [nombre=" + nombre + ", apellido=" + apellido + ", correo=" + correo + ", contrasenia="
				+ contrasenia + ", juegos=" + Arrays.toString(juegos) + "]";
	}

}
