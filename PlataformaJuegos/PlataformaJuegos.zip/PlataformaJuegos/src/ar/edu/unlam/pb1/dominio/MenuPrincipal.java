package ar.edu.unlam.pb1.dominio;

public enum MenuPrincipal {
	INICIAR_SESION, REGISTRARME
}
