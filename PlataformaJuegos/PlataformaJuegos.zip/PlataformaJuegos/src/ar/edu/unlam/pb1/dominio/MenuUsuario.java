package ar.edu.unlam.pb1.dominio;

public enum MenuUsuario {
	MIS_JUEGOS, TIENDA, JUEGO_MAS_JUGADO_POR_CATEGORIA, SALIR
}
