package ar.edu.unlam.pb1.dominio.enums;

public enum Genero {
	FEMENINO, MASCULINO 
}
