package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.Genero;

public class Discoteca {

	private static final int EDAD_MINIMA_FEMENINO = 18;
	private static final int EDAD_MINIMA_MASCULINO = 23;
	private int capacidad;
	private int contadorMasculinos;
	private int contadorFemeninos;

	public Discoteca(int capacidad) {
		this.capacidad = capacidad;
		this.contadorFemeninos = 0;
		this.contadorMasculinos = 0;
	}

	public boolean ingresarPersona(Persona persona) {
		boolean ingresa = false;

		if (this.obtenerTotalDePersonas() < this.getCapacidad()) {
			
			if (persona.getGenero().equals(Genero.MASCULINO) && persona.getEdad() >= EDAD_MINIMA_MASCULINO) {
				contadorMasculinos++;
				ingresa = true;
			} else if (persona.getGenero().equals(Genero.FEMENINO) && persona.getEdad() >= EDAD_MINIMA_FEMENINO) {
				contadorFemeninos++;
				ingresa = true;
			}			
		}
		
		return ingresa;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}

	public int getContadorMasculinos() {
		return contadorMasculinos;
	}

	public void setContadorMasculinos(int contadorMasculinos) {
		this.contadorMasculinos = contadorMasculinos;
	}

	public int getContadorFemeninos() {
		return contadorFemeninos;
	}

	public void setContadorFemeninos(int contadorFemeninos) {
		this.contadorFemeninos = contadorFemeninos;
	}

	public int obtenerTotalDePersonas() {
		return this.contadorFemeninos + this.contadorMasculinos;
	}

	@Override
	public String toString() {
		return "Discoteca [capacidad=" + capacidad + ", contadorMasculinos=" + contadorMasculinos
				+ ", contadorFemeninos=" + contadorFemeninos + ", total=" + this.obtenerTotalDePersonas() + "]";
	}

}
