package ar.edu.unlam.pb1.interfaz.enums;

public enum MenuPrincipal {

	INGRESAR_PERSONA("Ingresar personas"), 
	VER_RESUMEN_PERSONAS("Ver resumen"),
	MOSTRAR_CANTIDAD_MUJERES("Mostrar cantidad de mujeres"), 
	MOSTRAR_CANTIDAD_HOMBRES("Mostrar cantidad de hombres"),
	SALIR("Salir del sistema");

	private String descripcion;

	MenuPrincipal(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}
