package ar.edu.unlam.pb1.interfaz;

import java.util.Scanner;

import ar.edu.unlam.pb1.dominio.Discoteca;
import ar.edu.unlam.pb1.dominio.Persona;
import ar.edu.unlam.pb1.dominio.enums.Genero;
import ar.edu.unlam.pb1.interfaz.enums.MenuPrincipal;

public class TestEnum {
	
	//---------------------------------------------------------------- //
	// --------------------- LOGICA DEL PROGRAMA --------------------- //
	//---------------------------------------------------------------- //

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		generarNumeroAleatoria();
		
		MenuPrincipal opcionMenu = null;
		int opcion = 0;
		
		MenuPrincipal prueba  = MenuPrincipal.valueOf(null, null);
		System.out.println(prueba);
		
		int capacidad = ingresarEntero("Ingrese la capacidad a la discoteca", teclado);
		Discoteca discoteca = new Discoteca(capacidad);

		do {

			opcionMenu = mostrarMenuValidado(teclado);

			switch (opcionMenu) {
			case INGRESAR_PERSONA:
				ingresarPersonaValidada(teclado, discoteca);
				break;
			case VER_RESUMEN_PERSONAS:
				mostrarMensaje(discoteca.toString());
				break;
			case MOSTRAR_CANTIDAD_MUJERES:
				mostrarMensaje(discoteca.getContadorFemeninos());
				break;
			case MOSTRAR_CANTIDAD_HOMBRES:
				mostrarMensaje(discoteca.getCapacidad());
				break;
			case SALIR:
				System.out.println("Salir");
				break;

			}
		} while (!opcionMenu.equals(MenuPrincipal.SALIR));

		teclado.close();
	}

	private static MenuPrincipal mostrarMenuValidado(Scanner teclado) {
		MenuPrincipal opcionMenu;
		int opcion;
		mostrarMenuPrincipal();

		opcion = ingresarOpcionMenuValidada(teclado);

		opcionMenu = MenuPrincipal.values()[opcion - 1];
		return opcionMenu;
	}

	private static void ingresarPersonaValidada(Scanner teclado, Discoteca discoteca) {
		Persona persona = ingresarPersona(teclado);
		boolean personaIngresada = discoteca.ingresarPersona(persona);

		if (personaIngresada) {
			mostrarMensaje("Persona Ingresada!");
		} else {
			mostrarMensaje("No se puede ingresar");
		}
	}
	
	//--------------------------------------------------------------------- //
	// --------------------- METODOS PARA EL PROGRAMA --------------------- //
	//--------------------------------------------------------------------- //
	
	// --------------------- MOSTRAR MENU PRINCIPAL --------------------- //
	
	private static void mostrarMenuPrincipal() {
		MenuPrincipal opcion = null;
		int numero = 0;
		String menu = "";

		for (int i = 0; i < MenuPrincipal.values().length; i++) {
			opcion = MenuPrincipal.values()[i];
			numero = (opcion.ordinal() + 1);
			menu += "\n" + numero + ". " + opcion.getDescripcion();
		}

		System.out.println(menu);

	}


	// --------------------- INGRESAR PERSONA --------------------- //
	private static Persona ingresarPersona(Scanner teclado) {
		int edad = ingresarEntero("Ingresar la edad de la persona", teclado);
		Genero genero = ingresarGenero("Ingrese el genero de la persona", teclado);
		return new Persona(edad, genero);
	}

	
	// --------------------- INGRESAR NUMERO --------------------- //
	
	private static int ingresarOpcionMenuValidada(Scanner teclado) {
		int opcion;
		do {

			opcion = ingresarEntero("Ingrese la opcion", teclado);

		} while (opcion < 1 || opcion > MenuPrincipal.values().length);

		return opcion;
	}
	
	private static int ingresarEntero(String mensaje, Scanner teclado) {
		mostrarMensaje(mensaje);
		return teclado.nextInt();
	}
	
	private static void mostrarMensaje(int mensaje) {
		System.out.println(mensaje);
	}
	
	
	// --------------------- INGRESAR TEXTO --------------------- //
	
	private static Genero ingresarGenero(String mensaje, Scanner teclado) {
		mensaje += " F -> " + Genero.FEMENINO + ", M -> " + Genero.MASCULINO;
		Genero genero = Genero.FEMENINO;

		char caracterIngresado = '\0';

		mostrarMensaje(mensaje);
		caracterIngresado = teclado.next().charAt(0);

		if (caracterIngresado == 'M') {
			genero = Genero.MASCULINO;
		}

		return genero;
	}
	
	private static void mostrarMensaje(String mensaje) {
		System.out.println(mensaje);
	}

	
	private static void generarNumeroAleatoria() {
		
		//int prueba = (int)(Math.random() * ((max - min) + 1)) + min;
		
		int prueba = (int)(Math.random() * ((20 - 1) + 1)) + 1;
		mostrarMensaje(prueba);
	}
	
	
}
