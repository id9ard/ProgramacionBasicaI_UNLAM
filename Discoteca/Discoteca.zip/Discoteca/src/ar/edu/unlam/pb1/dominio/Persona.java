package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.Genero;

public class Persona {
	
	private int edad;
	private Genero genero;
	
	public Persona(int edad, Genero genero) {
		this.edad = edad;
		this.genero = genero;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	@Override
	public String toString() {
		return "Persona [edad=" + edad + ", genero=" + genero + "]";
	}
	
}
