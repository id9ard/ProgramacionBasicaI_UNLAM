package ar.edu.unlam.pb1.interfaz;

import java.util.Scanner;

import ar.edu.unlam.pb1.dominio.Paciente;
import ar.edu.unlam.pb1.dominio.HistoriaClinica;
import ar.edu.unlam.pb1.dominio.Hospital;
import ar.edu.unlam.pb1.dominio.enums.MotivoIngreso;
import ar.edu.unlam.pb1.interfaz.enums.MenuDoctor;
import ar.edu.unlam.pb1.interfaz.enums.MenuGuardia;
import ar.edu.unlam.pb1.interfaz.enums.MenuRecepcion;
import ar.edu.unlam.pb1.interfaz.enums.MenuTrueFalse;
import ar.edu.unlam.pb1.dominio.enums.ObraSocial;
import ar.edu.unlam.pb1.dominio.enums.TipoDeIngresoAGuardia;
import ar.edu.unlam.pb1.dominio.enums.Diagnostico;

public class InterfazHospital {

	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {

		// ---------------------------------------------------------------- //
		// --------------------- LOGICA DEL PROGRAMA --------------------- //
		// ---------------------------------------------------------------- //
		Hospital hospital = crearHospital();
		MenuGuardia opcionMenuGuardia = null;

		do {

			opcionMenuGuardia = opcionMenuGuardiaValidada();
			boolean sePudoVerificar;

			switch (opcionMenuGuardia) {
			case RECEPCION:
				sePudoVerificar = ingresarMenuGuardia(hospital);
				opcionMenuGuardia = verficarLimiteDeIntentos(opcionMenuGuardia, sePudoVerificar);
				break;
			case MEDICO:
				sePudoVerificar = ingresarMenuMedicos(hospital);
				opcionMenuGuardia = verficarLimiteDeIntentos(opcionMenuGuardia, sePudoVerificar);
				break;
			case SALIR:
				mostrarMensaje("Vuelve pronto!");
				break;
			}

		} while (!opcionMenuGuardia.equals(MenuGuardia.SALIR));
		

	}
	
	
	
	// ---------------------------------------------------------------- //
	// --------------------- METODOS DEL PROGRAMA --------------------- //
	// ---------------------------------------------------------------- //
	
	private static Hospital crearHospital() {
		int cantidadHabitaciones = 3;
		int cantidadConsultorios = 3;
		int cantidadHistoriasClinicas = 10;
		int cantidadBaseDeDatos = 10;

		Hospital hospital = new Hospital(cantidadHabitaciones, cantidadConsultorios, cantidadHistoriasClinicas, cantidadBaseDeDatos);
		return hospital;
	}

	private static boolean ingresarMenuGuardia(Hospital hospital) {
		boolean verificacionMenuPrincipal = ingresarSistemaRecepcion(hospital);

		if (verificacionMenuPrincipal) {

			MenuRecepcion opcionMenuPrincipal= null;

			do {

				opcionMenuPrincipal = opcionMenuPrincipalValidada();

				switch (opcionMenuPrincipal) {

				case INGRESAR_PACIENTES:
					System.out.println("---------- " + MenuRecepcion.INGRESAR_PACIENTES.toString() + " ----------");
					ingresarPaciente(hospital);
					break;
				case MOSTRAR_PACIENTES_ORDENADOS_POR_APELLIDO:
					System.out.println("---------- " + MenuRecepcion.MOSTRAR_PACIENTES_ORDENADOS_POR_APELLIDO.toString()
							+ " ----------");
					mostrarPacientesOrdenadosApellido(hospital);
					break;
				case MOSTRAR_POR_MOTIVO_DE_INGRESO:
					System.out.println(
							"---------- " + MenuRecepcion.MOSTRAR_POR_MOTIVO_DE_INGRESO.toString() + " ----------");
					mostrarPacientesMotivoIngreso(hospital, teclado);
					break;
				case MOSTRAR_PACIENTES_INTERNADOS:
					System.out.println(
							"---------- " + MenuRecepcion.MOSTRAR_PACIENTES_INTERNADOS.toString() + " ----------");
					mostrarPacientesInternados(hospital);
					break;
				case MOSTRAR_PACIENTES_EN_CONSULTA:
					System.out.println(
							"---------- " + MenuRecepcion.MOSTRAR_PACIENTES_EN_CONSULTA.toString() + " ----------");
					mostrarPacientesEnConsulta(hospital);
					break;
				case MOSTRAR_PACIENTES_POR_DNI:
					System.out.println("---------- " + MenuRecepcion.MOSTRAR_PACIENTES_POR_DNI.toString() + " ----------");
					mostrarPacientesPorDni(hospital);
					break;
				case MOSTRAR_BASE_DE_DATOS_DEL_HOSPITAL:
					System.out.println(
							"---------- " + MenuRecepcion.MOSTRAR_BASE_DE_DATOS_DEL_HOSPITAL.toString() + " ----------");
					mostrarBaseDeDatosDelHospital(hospital.getBaseDeDatos());
					break;
				case MOSTRAR_BASE_DE_DATOS_DEL_HOSPITAL_POR_ID:
					System.out.println(
							"---------- " + MenuRecepcion.MOSTRAR_BASE_DE_DATOS_DEL_HOSPITAL_POR_ID.toString() + " ----------");
					mostrarBaseDeDatosPorId(hospital);
					break;
				case MOSTRAR_PACIENTES_POR_FECHA_DE_INGRESO:
					System.out.println(
							"---------- " + MenuRecepcion.MOSTRAR_PACIENTES_POR_FECHA_DE_INGRESO.toString() + " ----------");
					mostrarBaseDeDatosPorFechaInhreso(hospital);
					break;
				case SALIR:
					break;

				}

			} while (!opcionMenuPrincipal.equals(MenuRecepcion.SALIR));

		} else {
			mostrarMensaje("No se pudo verificar la contraseña. Hasta luego!");
		}
		return verificacionMenuPrincipal;
	}
	
	private static boolean ingresarMenuMedicos(Hospital hospital) {
		boolean verificacionAdmin = ingresarSistemaDoctor(hospital);

		if (verificacionAdmin) {

			MenuDoctor opcionMenuAdmin = null;

			do {

				opcionMenuAdmin = opcionMenuAdminValidado();

				switch (opcionMenuAdmin) {

				case INGRESAR_HISTORIA_CLINICA_DE_PACIENTE_INTERNADO:
					System.out.println("---------- " + MenuDoctor.INGRESAR_HISTORIA_CLINICA_DE_PACIENTE_INTERNADO.toString() + " ----------");
					ingresarHistoriaClinica(hospital);
					break;
				case DERIVAR_PACIENTES_A_INTERNACION:
					System.out.println(
							"---------- " + MenuDoctor.DERIVAR_PACIENTES_A_INTERNACION.toString() + " ----------");
					derivarPacienteParaInternacion(hospital);
					break;
				case ALTA_DEL_PACIENTE:
					System.out.println(
							"---------- " + MenuDoctor.ALTA_DEL_PACIENTE.toString() + " ----------");
					darAltaPaciente(hospital);
					break;
				case MOSTRAR_HISTORIA_CLINICA_POR_DNI:
					System.out.println(
							"---------- " + MenuDoctor.MOSTRAR_HISTORIA_CLINICA_POR_DNI.toString() + " ----------");
					mostrarhistoriasClinicasPorDNI(hospital, teclado);
					break;
				case SALIR:
					break;
				}

			} while (!opcionMenuAdmin.equals(MenuDoctor.SALIR));

		} else {
			mostrarMensaje("No se pudo verificar la contraseña. Hasta luego!");
		}
		return verificacionAdmin;
	}


	// --------------------- INICIAR SESION EN EL SISTEMA ----------------------- //
	private static boolean ingresarSistemaRecepcion(Hospital hospital) {

		boolean validacionCorrecta = false;
		String claveUsuario;
		int contadorIntentos = 0;

		mostrarMensaje("\n---------- BIENVENIDO AL SISTEMA DE RECEPCION ----------");

		do {

			claveUsuario = ingresarString("\nIngrese Contraseña :", teclado);
			if (hospital.iniciarSesionRecepcion(claveUsuario)) {
				validacionCorrecta = true;
			} else {
				validacionCorrecta = false;
				contadorIntentos++;
				if (contadorIntentos < 3) {
					mostrarMensaje("Contraseña incorrecta! " 
							+ contadorIntentos + " Intento(s) realizado(s).");
				} else {
					mostrarMensaje("Superó el limite de intentos!");
				}

			}

		} while (!validacionCorrecta && contadorIntentos < 3);

		return validacionCorrecta;

	}
	
	private static boolean ingresarSistemaDoctor(Hospital hospital) {

		boolean validacionCorrecta = false;
		String claveAdmin;
		int contadorIntentos = 0;
		
		mostrarMensaje("\n---------- BIENVENIDO AL SISTEMA DE DOCTORES ----------");

		do {

			claveAdmin = ingresarString("\nIngrese Contraseña : " , teclado);
			if (hospital.iniciarSesionDoctor(claveAdmin)) {
				validacionCorrecta = true;
			} else {
				validacionCorrecta = false;
				contadorIntentos++;
				if (contadorIntentos < 3) {
					mostrarMensaje("Contraseña incorrecta! " 
							+ contadorIntentos + " Intento(s) realizado(s).");
				} else {
					mostrarMensaje("Superó el limite de intentos!");
				}

			}

		} while (!validacionCorrecta && contadorIntentos < 3);

		return validacionCorrecta;

	}


	// --------------------- VERIFICAR LIMITE DE INTENTOS ----------------------- //
	private static MenuGuardia verficarLimiteDeIntentos(MenuGuardia opcionMenuGuardia, boolean sePudoVerificar) {
		if(!sePudoVerificar) {
		opcionMenuGuardia = MenuGuardia.SALIR;
		}
		return opcionMenuGuardia;
	}
	
	// --------------------- MOSTRAR MENU ----------------------- //
	private static void mostrarMenu(String mensaje) {
		String ingresarMenu = mensaje;

		switch (ingresarMenu) {

		case "MENU_GUARDIA":
			for (MenuGuardia menu : MenuGuardia.values()) {
				System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
			}
			break;
		case "MENU_RECEPCION":
			for (MenuRecepcion menu : MenuRecepcion.values()) {
				System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
			}
			break;
		case "OBRA_SOCIAL":
			for (ObraSocial menu : ObraSocial.values()) {
				System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
			}
			break;
		case "MOTIVO_INGRESO":
			for (MotivoIngreso menu : MotivoIngreso.values()) {
				System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
			}
			break;
		case "DIAGNOSTICO":
			for (Diagnostico menu : Diagnostico.values()) {
				System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
			}
			break;
		case "MENU_DOCTORES":
			for (MenuDoctor menu : MenuDoctor.values()) {
				System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
			}
			break;
		case "MENU_TRUE_FALSE":
			for (MenuTrueFalse menu : MenuTrueFalse.values()) {
				System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
			}
			break;
		case "MENU_INTERNACION":
			for (TipoDeIngresoAGuardia menu : TipoDeIngresoAGuardia.values()) {
				System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
			}
			break;
		}

	}

	// --------------------- VALIDAR MENU ----------------------- //
	private static int validarMenu(int longitud, Scanner teclado) {

		String opcionUsuario;
		boolean opcionUsuarioValidada = false;
		int opcionMenu;

		do {

			do {
				opcionUsuario = ingresarString("\nIngresar una opcion del menu :", teclado);
				opcionUsuarioValidada = validarEntero(opcionUsuario);

			} while (!opcionUsuarioValidada);

			opcionMenu = Integer.parseInt(opcionUsuario);

		} while (opcionMenu < 1 || opcionMenu > longitud);

		return opcionMenu;
	}

	private static MenuDoctor opcionMenuAdminValidado() {
		MenuDoctor opcionMenuAdmin;
		int opcionAdmin;
		mostrarMensaje("\n---------- SISTEMA DE DOCTORES ----------" + "\n");

		mostrarMenu("MENU_DOCTORES");

		opcionAdmin = validarMenu(MenuDoctor.values().length, teclado);
		opcionMenuAdmin = MenuDoctor.values()[opcionAdmin - 1];
		return opcionMenuAdmin;
	}

	private static MenuRecepcion opcionMenuPrincipalValidada() {
		MenuRecepcion opcionMenu;
		int opcionUsuario;
		mostrarMensaje("\n---------- SISTEMA DE RECEPCION ----------" + "\n");

		mostrarMenu("MENU_RECEPCION");

		opcionUsuario = validarMenu(MenuRecepcion.values().length, teclado);
		opcionMenu = MenuRecepcion.values()[opcionUsuario - 1];
		return opcionMenu;
	}
	
	private static MenuGuardia opcionMenuGuardiaValidada() {
		MenuGuardia opcionMenu;
		int opcionUsuario;
		mostrarMensaje("\n---------- SISTEMA GENERAL ----------" + "\n");

		mostrarMenu("MENU_GUARDIA");

		opcionUsuario = validarMenu(MenuGuardia.values().length, teclado);
		opcionMenu = MenuGuardia.values()[opcionUsuario - 1];
		return opcionMenu;
	}

	private static String comprobarDni(Scanner teclado) {
		String dniValidado;
		boolean numeroValidado = false;

		do {

			dniValidado = ingresarString("Ingresar el dni :", teclado);

			if (dniValidado.length() == 8) {
				numeroValidado = validarEntero(dniValidado);
			} else {
				numeroValidado = false;
			}

		} while (!numeroValidado);

		return dniValidado;
	}

	// --------------------- INGRESAR PACIENTE ----------------------- //
	private static Paciente agregarPaciente(Hospital hospital, String dniValidado) {

		boolean numeroFechaValidada;
		String fechaValidada;

		boolean stringNombreValidado;
		String nombreValidado;

		boolean stringApellidoValidado;
		String apellidoValidado;

		int edadValidadoParseado = 0;
		String edadValidado;
		boolean numeroValidado = false;

		ObraSocial opcionObraSocial = null;
		int opcionUsuarioObraSocial;

		MotivoIngreso opcionMotivoIngreso = null;
		int opcionUsuarioMotivoIngreso;

		TipoDeIngresoAGuardia opcionInternacion = null;
		int opcionUsuarioInternacion;

		int habitacionConsulAleatorio;

		do {

			fechaValidada = ingresarString("Ingresar la fecha en el siguiente formato(1900-12-20) :", teclado);

			if (numeroFechaValidada = validarFecha(fechaValidada) && fechaValidada.length() == 10) {
				numeroFechaValidada = true;
			} else {
				numeroFechaValidada = false;
			}

		} while (!numeroFechaValidada);

		do {

			nombreValidado = ingresarString("Ingresar Nombre :", teclado);

			stringNombreValidado = validarString(nombreValidado);

		} while (!stringNombreValidado);

		do {

			apellidoValidado = ingresarString("Ingresar Apellido :", teclado);

			stringApellidoValidado = validarString(apellidoValidado);

		} while (!stringApellidoValidado);

		do {

			edadValidado = ingresarString("Ingresar la edad :", teclado);

			if (numeroValidado = validarEntero(edadValidado)) {
				edadValidadoParseado = Integer.parseInt(edadValidado);
				if (edadValidadoParseado >= 1 && edadValidadoParseado <= 100) {
					numeroValidado = true;
				} else {
					numeroValidado = false;
				}
			}

		} while (!numeroValidado);

		mostrarMensaje("Ingresar obra social :");
		mostrarMenu("OBRA_SOCIAL");
		opcionUsuarioObraSocial = validarMenu(ObraSocial.values().length, teclado);
		opcionObraSocial = ObraSocial.values()[opcionUsuarioObraSocial - 1];

		mostrarMensaje("Ingresar motivo de ingreso :");
		mostrarMenu("MOTIVO_INGRESO");
		opcionUsuarioMotivoIngreso = validarMenu(MotivoIngreso.values().length, teclado);
		opcionMotivoIngreso = MotivoIngreso.values()[opcionUsuarioMotivoIngreso - 1];

		mostrarMensaje("Internacion/Consultorio");
		mostrarMenu("MENU_INTERNACION");
		opcionUsuarioInternacion = validarMenu(TipoDeIngresoAGuardia.values().length, teclado);
		opcionInternacion = TipoDeIngresoAGuardia.values()[opcionUsuarioInternacion - 1];

		if (opcionInternacion.equals(TipoDeIngresoAGuardia.CONSULTORIO)) {
			habitacionConsulAleatorio = hospital.generarConsultorioAleatorio();
		} else {
			habitacionConsulAleatorio = hospital.generarHabitacionAleatoria();
		}

		return new Paciente(Hospital.getIdPaciente(), habitacionConsulAleatorio, fechaValidada, nombreValidado,
				apellidoValidado, edadValidadoParseado, dniValidado, opcionObraSocial, opcionMotivoIngreso,
				opcionInternacion);

	}

	// --------------------- VALIDAR PACIENTE INGRESADO ----------------------- //
	private static void ingresarPaciente(Hospital hospital) {
		int cantidadDePacientes = hospital.cantidadPacientesInternados() + hospital.cantidadPacientesEnConsulta();

		if (hospital.getPacientes().length == cantidadDePacientes) {
			mostrarMensaje("El hospital se encuentra lleno!");

		} else {
			String dniValidado = comprobarDni(teclado);

			if (hospital.validarDniHospital(dniValidado)) {
				mostrarMensaje("Ya existe el DNI en el sistema");
			} else {
				Paciente paciente = agregarPaciente(hospital, dniValidado);
				
				if(paciente.getTipoDeIngresoAInternacion().equals(TipoDeIngresoAGuardia.INTERNACION) &&
						hospital.getCantidadHabitacionesParaInternacion() > hospital.cantidadPacientesInternados()) {
						hospital.ingresarPacienteHospital(paciente);
						mostrarMensaje("El paciente fue ingresado!");
				} else if(paciente.getTipoDeIngresoAInternacion().equals(TipoDeIngresoAGuardia.CONSULTORIO) &&
						hospital.getCantidadConsultorios() > hospital.cantidadPacientesEnConsulta()) {
						hospital.ingresarPacienteHospital(paciente);
						mostrarMensaje("El paciente fue ingresado!");
				} else {
					mostrarMensaje("\nNo se pudo ingresar al paciente!. Revisar el historial de ingresos al hospital" + "\n" + hospital.toString());
				}
				
			}
		}

	}

	// --------------------- VALIDAR PACIENTE POR MOTIVO DE INGRESO ----------------------- //
	private static void mostrarPacientesMotivoIngreso(Hospital hospital, Scanner teclado) {

		MotivoIngreso opcionMotivoIngreso = null;
		int opcionUsuarioMotivoIngreso;

		mostrarMensaje("Ingresar el motivo de Ingreso :");
		mostrarMenu("MOTIVO_INGRESO");
		opcionUsuarioMotivoIngreso = validarMenu(MotivoIngreso.values().length, teclado);
		opcionMotivoIngreso = MotivoIngreso.values()[opcionUsuarioMotivoIngreso - 1];

		boolean validarPacientes = hospital.buscarPacientesDeUnTipoDeDiagnstico(opcionMotivoIngreso);

		if (validarPacientes) {
			Paciente[] pacientesObtenidos = hospital.obtenerPacientesDeUnTipoDeDiagnstico(opcionMotivoIngreso);
			mostrarPacientes(pacientesObtenidos);
		} else {
			mostrarMensaje("No hay pacientes con este motivo de ingreso!");
		}

	}

	// --------------------- MOSTRAR PACIENTES ORDENADOS POR APELLIDO ----------------------- //
	private static void mostrarPacientesOrdenadosApellido(Hospital hospital) {

		int verificarPacientes = hospital.cantidadPacientesInternados() + hospital.cantidadPacientesEnConsulta();

		if (verificarPacientes >= 1) {
			Paciente[] pacientesOrdenadosApellido = hospital.obtenerPacientesOrdenadosPorApellido();
			mostrarPacientes(pacientesOrdenadosApellido);
		} else {
			mostrarMensaje("No hay pacientes ingresados");
		}

	}

	// --------------------- MOSTRAR PACIENTES POR DNI ----------------------- //
	private static void mostrarPacientesPorDni(Hospital hospital) {
		String dni = comprobarDni(teclado);
		Paciente paciente = hospital.obtenerPaciente(dni);
		
		if(paciente != null) {
			System.out.println(paciente);
		} else {
			mostrarMensaje("No se encontró al paciente!");
		}
	}


	// --------------------- DAR DE ALTA AL PACIENTE ----------------------- //
	private static void darAltaPaciente(Hospital hospital) {
		String dni = comprobarDni(teclado);
		boolean sePudoDarDeAlta = hospital.darAltaPaciente(dni);

		if (sePudoDarDeAlta) {
			mostrarMensaje("Se pudo dar de Alta al paciente");
		} else {
			mostrarMensaje("No es paciente del Hospital!");
		}
	}
	
	// --------------------- DERIVAR PACIENTE ----------------------- //
	private static void derivarPacienteParaInternacion(Hospital hospital) {
		long idValidadoParseado = 0;
		String idValidado;
		boolean numeroValidado = false;

		do {

			if(hospital.contarPacientesPorTipoDeInternacion(TipoDeIngresoAGuardia.CONSULTORIO) > 0) {
				mostrarPacientesEnConsulta(hospital);
				idValidado = ingresarString("Ingresar el id :", teclado);

				if (numeroValidado = validarEntero(idValidado)) {
					idValidadoParseado = Integer.parseInt(idValidado);
					numeroValidado = true;
				} 
			} else {
				numeroValidado = true;
			}
			
			

		} while (!numeroValidado);

		boolean sePudoDerivar = hospital.derivarPacienteAInternacion(idValidadoParseado);

		if (sePudoDerivar) {
			mostrarMensaje("Se pudo derivar al paciente");
		} else {
			mostrarMensaje("No se pudo derivar al paciente!");
		}
	}

	// --------------------- VALIDAR PACIENTES INTERNADOS ----------------------- //
	private static void mostrarPacientesInternados(Hospital hospital) {
		int pacientesIngresados = hospital.contarPacientesPorTipoDeInternacion(TipoDeIngresoAGuardia.INTERNACION);

		if (pacientesIngresados >= 1) {
			Paciente[] pacientesObtenidos = hospital.buscarPacientesDeUnTipoDeInternacion(TipoDeIngresoAGuardia.INTERNACION);
			mostrarPacientes(pacientesObtenidos);
		} else {
			mostrarMensaje("No hay pacientes ingresados hasta el momento.");
		}

	}

	// --------------------- MOSTRAR PACIENTES EN CONSULTA ----------------------- //
	private static void mostrarPacientesEnConsulta(Hospital hospital) {
		int pacientesIngresados = hospital.contarPacientesPorTipoDeInternacion(TipoDeIngresoAGuardia.CONSULTORIO);

		if (pacientesIngresados >= 1) {
			Paciente[] pacientesObtenidos = hospital.buscarPacientesDeUnTipoDeInternacion(TipoDeIngresoAGuardia.CONSULTORIO);
			mostrarPacientes(pacientesObtenidos);
		} else {
			mostrarMensaje("No hay pacientes ingresados hasta el momento.");
		}

	}

	// --------------------- VALIDAR PACIENTES INGRESADOS EN BASE DE DATOS ----------------------- //
	private static void mostrarBaseDeDatosDelHospital(Paciente[] baseDeDatos) {
		for (int indice = 0; indice < baseDeDatos.length; indice++) {
			if (baseDeDatos[indice] != null) {
				System.out.println(baseDeDatos[indice]);
			}
		}
	}

	// --------------------- MOSTRAR PACIENTES DE BASE DE DATOS ----------------------- //
	private static void mostrarBaseDeDatosPorId(Hospital hospital) {
		long idValidadoParseado = 0;
		String idValidado;
		boolean numeroValidado = false;

		do {
			
				idValidado = ingresarString("Ingresar el id :", teclado);

				if (numeroValidado = validarEntero(idValidado)) {
					idValidadoParseado = Integer.parseInt(idValidado);
					numeroValidado = true;
				} 

		} while (!numeroValidado);

		Paciente[] pacientesPorId =  hospital.obtenerBaseDeDatosPorID(idValidadoParseado);
		mostrarBaseDeDatos(pacientesPorId);
	}
	
	// --------------------- MOSTRAR PACIENTES DE BASE DE DATOS POR FECHA DE INGRESO ----------------------- //
	private static void mostrarBaseDeDatosPorFechaInhreso(Hospital hospital) {
		boolean numeroFechaValidada;
		String fechaValidada;

		do {

			fechaValidada = ingresarString("Ingresar la fecha en el siguiente formato(1900-12-20) :", teclado);

			if (numeroFechaValidada = validarFecha(fechaValidada) && fechaValidada.length() == 10) {
				numeroFechaValidada = true;
			} else {
				numeroFechaValidada = false;
			}

		} while (!numeroFechaValidada);
		
		Paciente[] pacientesPorFechaIngreso =  hospital.obtenerBaseDeDatosPorFechaDeIngreso(fechaValidada);
		mostrarBaseDeDatos(pacientesPorFechaIngreso);

	}
	
	// --------------------- AGREGAR HISTORIA CLINICA ----------------------- //
	private static HistoriaClinica agregarHistoriaClinica(Hospital hospital, String dniValidado) {

		boolean numeroFechaValidada;
		String fechaValidada;

		int frecuenciaCardiacaValidadaParseada = 0;
		boolean numerofrecuenciaCardiacaValidada;
		String frecuenciaCardiacaValidada;

		int frecuenciaRespiratoriaValidadaParseada = 0;
		boolean numerofrecuenciaRespiratoriaValidada;
		String frecuenciaRespiratoriaValidada;

		int frecuenciaSaturacionOxigenoValidadaParseada = 0;
		boolean numerofrecuenciaSaturacionOxigenoValidada;
		String frecuenciaSaturacionOxigenoValidada;

		int frecuenciaGlucemiaValidadaParseada = 0;
		boolean numerofrecuenciaGlucemiaValidada;
		String frecuenciaGlucemiaValidada;

		int temperaturaValidadaParseada = 0;
		boolean numerotemperaturaValidada;
		String temperaturaValidada;

		Diagnostico opcionDiagnostico = null;
		int opcionUsuarioDiagnostico;

		MenuTrueFalse opcionOrientado = null;
		int opcionUsuarioOrientado;

		MenuTrueFalse opcionRespuestaMotora = null;
		int opcionUsuarioRespuestaMotora;

		MenuTrueFalse opcionAperturaOcular = null;
		int opcionUsuarioAperturaOcular;

		do {

			fechaValidada = ingresarString("Ingresar la fecha en el siguiente formato(1900-12-20) :", teclado);

			if (numeroFechaValidada = validarFecha(fechaValidada) && fechaValidada.length() == 10) {
				numeroFechaValidada = true;
			} else {
				numeroFechaValidada = false;
			}

		} while (!numeroFechaValidada);

		do {

			frecuenciaCardiacaValidada = ingresarString("Ingrese la F.C:", teclado);

			if (numerofrecuenciaCardiacaValidada = validarEntero(frecuenciaCardiacaValidada)) {
				frecuenciaCardiacaValidadaParseada = Integer.parseInt(frecuenciaCardiacaValidada);
				if (frecuenciaCardiacaValidadaParseada >= 55 && frecuenciaCardiacaValidadaParseada <= 200) {
					numerofrecuenciaCardiacaValidada = true;
				} else {
					numerofrecuenciaCardiacaValidada = false;
				}
			}

		} while (!numerofrecuenciaCardiacaValidada);

		do {

			frecuenciaRespiratoriaValidada = ingresarString("Ingrese la F.R:", teclado);

			if (numerofrecuenciaRespiratoriaValidada = validarEntero(frecuenciaRespiratoriaValidada)) {
				frecuenciaRespiratoriaValidadaParseada = Integer.parseInt(frecuenciaRespiratoriaValidada);
				if (frecuenciaRespiratoriaValidadaParseada >= 8 && frecuenciaRespiratoriaValidadaParseada <= 25) {
					numerofrecuenciaRespiratoriaValidada = true;
				} else {
					numerofrecuenciaRespiratoriaValidada = false;
				}
			}

		} while (!numerofrecuenciaRespiratoriaValidada);

		do {

			frecuenciaSaturacionOxigenoValidada = ingresarString("Ingrese la SAT O2", teclado);

			if (numerofrecuenciaSaturacionOxigenoValidada = validarEntero(frecuenciaSaturacionOxigenoValidada)) {
				frecuenciaSaturacionOxigenoValidadaParseada = Integer.parseInt(frecuenciaSaturacionOxigenoValidada);
				if (frecuenciaSaturacionOxigenoValidadaParseada >= 80
						&& frecuenciaSaturacionOxigenoValidadaParseada <= 105) {
					numerofrecuenciaSaturacionOxigenoValidada = true;
				} else {
					numerofrecuenciaSaturacionOxigenoValidada = false;
				}
			}

		} while (!numerofrecuenciaSaturacionOxigenoValidada);

		do {

			frecuenciaGlucemiaValidada = ingresarString("Ingrese la Glucemia:", teclado);

			if (numerofrecuenciaGlucemiaValidada = validarEntero(frecuenciaGlucemiaValidada)) {
				frecuenciaGlucemiaValidadaParseada = Integer.parseInt(frecuenciaGlucemiaValidada);
				if (frecuenciaGlucemiaValidadaParseada >= 50 && frecuenciaGlucemiaValidadaParseada <= 600) {
					numerofrecuenciaGlucemiaValidada = true;
				} else {
					numerofrecuenciaGlucemiaValidada = false;
				}
			}

		} while (!numerofrecuenciaGlucemiaValidada);

		do {

			temperaturaValidada = ingresarString("Ingrese la Temperatura:", teclado);

			if (numerotemperaturaValidada = validarEntero(temperaturaValidada)) {
				temperaturaValidadaParseada = Integer.parseInt(temperaturaValidada);
				if (temperaturaValidadaParseada >= 35 && temperaturaValidadaParseada <= 42) {
					numerotemperaturaValidada = true;
				} else {
					numerotemperaturaValidada = false;
				}
			}

		} while (!numerotemperaturaValidada);

		mostrarMensaje("Ingresar el diagnostico :");
		mostrarMenu("DIAGNOSTICO");
		opcionUsuarioDiagnostico = validarMenu(Diagnostico.values().length, teclado);
		opcionDiagnostico = Diagnostico.values()[opcionUsuarioDiagnostico - 1];

		mostrarMensaje("Orientado? :");
		mostrarMenu("MENU_TRUE_FALSE");
		opcionUsuarioOrientado = validarMenu(MenuTrueFalse.values().length, teclado);
		opcionOrientado = MenuTrueFalse.values()[opcionUsuarioOrientado - 1];

		mostrarMensaje("Respuesta Motora? :");
		mostrarMenu("MENU_TRUE_FALSE");
		opcionUsuarioRespuestaMotora = validarMenu(MenuTrueFalse.values().length, teclado);
		opcionRespuestaMotora = MenuTrueFalse.values()[opcionUsuarioRespuestaMotora - 1];

		mostrarMensaje("Apertura Ocular? :");
		mostrarMenu("MENU_TRUE_FALSE");
		opcionUsuarioAperturaOcular = validarMenu(MenuTrueFalse.values().length, teclado);
		opcionAperturaOcular = MenuTrueFalse.values()[opcionUsuarioAperturaOcular - 1];

		return new HistoriaClinica(dniValidado, fechaValidada, opcionDiagnostico, frecuenciaCardiacaValidadaParseada,
				frecuenciaRespiratoriaValidadaParseada, frecuenciaSaturacionOxigenoValidadaParseada,
				frecuenciaGlucemiaValidadaParseada, temperaturaValidadaParseada, opcionOrientado, opcionRespuestaMotora,
				opcionAperturaOcular);

	}

	// --------------------- INGRESAR HISTORIA CLINICA ----------------------- //
	private static void ingresarHistoriaClinica(Hospital hospital) {

		if (hospital.cantidadHistoriasClinicasIngresadas() == hospital.getHistoriasClinicas().length) {

			mostrarMensaje("No se pueden ingresar mas historias clinicas.");

		} else {
			String dniValidado = comprobarDni(teclado);
			Paciente paciente = hospital.obtenerPaciente(dniValidado);

			if (hospital.validarDniHospital(dniValidado) && paciente.getTipoDeIngresoAInternacion().equals(TipoDeIngresoAGuardia.INTERNACION)) {
				HistoriaClinica historiaClinica = agregarHistoriaClinica(hospital, dniValidado);
				hospital.ingresarHistoriasClinicasHospital(historiaClinica);
				mostrarMensaje("La historia clinica fue ingresada!");

			} else {
				mostrarMensaje("El paciente no se encuentra internado.");
			}
		}

	}

	// --------------------- MOSTRAR HISTORIAS CLINICAS ----------------------- //
	private static void mostrarhistoriasClinicasPorDNI(Hospital hospital, Scanner teclado) {
		int historiasClinicasIngresados = hospital.cantidadHistoriasClinicasIngresadas();
		String dni = comprobarDni(teclado);
		boolean pacienteExisteHospital = hospital.validarDniHospital(dni);
		boolean pacienteExisteBaseDeDatos = hospital.validarDniBaseDeDatos(dni);

		if (pacienteExisteBaseDeDatos && historiasClinicasIngresados >= 1) {
			HistoriaClinica[] historiasClinicas = hospital.obtnerHistoriasClinicasPorDni(dni);
			mostrarMensaje("Se econtraron " + hospital.contadorHistoriasClinicasPorDni(dni)
					+ " registro(s) para este numero de DNI :");
			mostrarHisoriasClinicas(historiasClinicas);
		} else if (pacienteExisteHospital && hospital.validarDniBaseDeDatos(dni) && historiasClinicasIngresados == 0) {
			mostrarMensaje("El paciente aun no cuenta con historias clinicas");

		} else {
			mostrarMensaje("No existen registros del paciente.");
		}

	}

	// --------------------- MOSTRAR BASE DE DATOS ----------------------- //
	private static void mostrarBaseDeDatos(Paciente[] baseDeDatos) {
		for (int indice = 0; indice < baseDeDatos.length; indice++) {
			if (baseDeDatos[indice] != null) {
				System.out.println(baseDeDatos[indice]);
			}
		}
	}
	
	// --------------------- MOSTRAR HISTORIAS CLINICAS ----------------------- //
	private static void mostrarHisoriasClinicas(HistoriaClinica[] historiasClinicas) {
		for (int indice = 0; indice < historiasClinicas.length; indice++) {
			if (historiasClinicas[indice] != null) {
				System.out.println(historiasClinicas[indice]);
			}
		}
	}

	// --------------------- VALIDAR NUMERO ----------------------- //
	private static boolean validarEntero(String teclado) {

		boolean esNumero = false;

		for (int posicion = 0; posicion < teclado.length(); posicion++) {
			if ((teclado.charAt(posicion) >= 48 && teclado.charAt(posicion) <= 57)) {
				esNumero = true;
			} else {
				esNumero = false;
				break;
			}
		}

		return esNumero;
	}

	// --------------------- VALIDAR FECHA ----------------------- //
	private static boolean validarFecha(String teclado) {

		boolean esNumero = false;

		for (int posicion = 0; posicion < teclado.length(); posicion++) {
			if ((teclado.charAt(posicion) >= 48 && teclado.charAt(posicion) <= 57) || teclado.charAt(posicion) == 45) {
				esNumero = true;
			} else {
				esNumero = false;
				break;
			}
		}

		return esNumero;
	}

	// --------------------- VALIDAR TEXTO ----------------------- //
	private static boolean validarString(String teclado) {

		boolean esString = false;

		for (int posicion = 0; posicion < teclado.length(); posicion++) {
			if ((teclado.charAt(posicion) >= 65 && teclado.charAt(posicion) <= 90)
					|| (teclado.charAt(posicion) >= 97 && teclado.charAt(posicion) <= 122)
					|| (teclado.charAt(posicion) == 32)) {
				esString = true;
			} else {
				esString = false;
				break;
			}
		}

		return esString;
	}

	// --------------------- INGRESAR STRING ----------------------- //
	private static String ingresarString(String mensaje, Scanner teclado) {
		mostrarMensaje(mensaje);
		return teclado.nextLine();
	}

	// --------------------- MOSTRAR MENSAJE ----------------------- //
	private static void mostrarMensaje(String mensaje) {
		System.out.println(mensaje);
	}

	// --------------------- RECORRER ARRAY ----------------------- //
	private static void mostrarPacientes(Paciente[] pacientes) {
		for (int indice = 0; indice < pacientes.length; indice++) {
			if (pacientes[indice] != null) {
				System.out.println(pacientes[indice]);
			}
		}
	}
}
