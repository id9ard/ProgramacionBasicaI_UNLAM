package ar.edu.unlam.pb1.interfaz.enums;

public enum MenuDoctor {
	INGRESAR_HISTORIA_CLINICA_DE_PACIENTE_INTERNADO("Ingresar historia clinica de paciente internado :"),
	DERIVAR_PACIENTES_A_INTERNACION("Derivar paciente a internacion:"),
	ALTA_DEL_PACIENTE("Dar de alta al paciente"),
	MOSTRAR_HISTORIA_CLINICA_POR_DNI("Mostrar historia clinica por dni :"), 
	SALIR("Volver al menu Principal");

	private String descripcion;

	MenuDoctor(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDescripcion() {
		return descripcion;
	}
}
