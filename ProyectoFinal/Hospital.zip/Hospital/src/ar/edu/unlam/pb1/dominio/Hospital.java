package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.MotivoIngreso;
import ar.edu.unlam.pb1.dominio.enums.TipoDeIngresoAGuardia;

public class Hospital {

	private static long idPaciente = 0;
	
	private int cantidadHabitacionesParaInternacion;
	private int cantidadConsultorios;
	
	private String CONTRASENIA_RECEPCION = "user";
	private String CONTRASENIA_DOCTOR = "admin";
	
	private Usuario recepcion;
	private Usuario doctor;
	
	private Paciente[] pacientes;
	private Paciente[] baseDeDatos;
	private HistoriaClinica[] historiasClinicas;

	public Hospital(int cantidadHabitacionesParaInternacion, int cantidadConsultorios, int cantidadHistoriasClinicas,
			int cantidadDeLaBaseDeDatos) {
		this.historiasClinicas = new HistoriaClinica[cantidadHistoriasClinicas];
		this.pacientes = new Paciente[cantidadHabitacionesParaInternacion + cantidadConsultorios];
		this.baseDeDatos = new Paciente[cantidadDeLaBaseDeDatos];
		this.recepcion = new Usuario(CONTRASENIA_RECEPCION);
		this.doctor = new Usuario(CONTRASENIA_DOCTOR);
		this.cantidadHabitacionesParaInternacion = cantidadHabitacionesParaInternacion;
		this.cantidadConsultorios = cantidadConsultorios;
	}

	public HistoriaClinica[] getHistoriasClinicas() {
		return historiasClinicas;
	}

	public Paciente[] getPacientes() {
		return pacientes;
	}

	public Paciente[] getBaseDeDatos() {
		return baseDeDatos;
	}

	public int getCantidadHabitacionesParaInternacion() {
		return cantidadHabitacionesParaInternacion;
	}

	public void setCantidadHabitacionesParaInternacion(int cantidadHabitacionesParaInternacion) {
		this.cantidadHabitacionesParaInternacion = cantidadHabitacionesParaInternacion;
	}

	public int getCantidadConsultorios() {
		return cantidadConsultorios;
	}

	public void setCantidadConsultorios(int cantidadConsultorios) {
		this.cantidadConsultorios = cantidadConsultorios;
	}

	public static long getIdPaciente() {
		return idPaciente;
	}

	
	// -----------------------------------------------------------------
	// ------------------------- INICIAR SESION ------------------------
	// -----------------------------------------------------------------
	
	// INICIO DE SESION DEL MENU RECEPCION //
	public boolean iniciarSesionRecepcion(String contrasenia) {
		boolean ingresar = false;

		if (recepcion.getContrasenia().equals(contrasenia)) {
			return ingresar = true;
		}

		return ingresar;
	}
	
	// INICIO DE SESION DEL MENU DOCTOR //
	public boolean iniciarSesionDoctor(String contrasenia) {
		boolean ingresar = false;

		if (doctor.getContrasenia().equals(contrasenia)) {
			return ingresar = true;
		}

		return ingresar;
	}
	
	
	// -----------------------------------------------------------------
	// ------------------------- INGRESAR A ARRAY ----------------------
	// -----------------------------------------------------------------
	

	// INGRESAR PACIENTE A HOSPITAL Y A BASE DE DATOS(AUTOMATICAMENTE) //
	public boolean ingresarPacienteHospital(Paciente paciente) {

		boolean agregado = false;
		int posicion = 0;
		boolean existeBaseDeDatos = this.validarDniBaseDeDatos(paciente.getDni());
		Paciente pacienteExisteBaseDeDatos = this.obtenerPacienteBaseDeDatos(paciente.getDni());
		
		if (existeBaseDeDatos) {

			while (posicion < this.pacientes.length && !agregado) {
				if (this.pacientes[posicion] == null) {
					this.pacientes[posicion] = new Paciente(pacienteExisteBaseDeDatos.getId(), paciente.getHabitacionOConsultorio(),
							paciente.getFechaIngreso(), paciente.getNombre(), paciente.getApellido(),
							paciente.getEdad(), paciente.getDni(), paciente.getObraSocial(),
							paciente.getMotivoIngreso(), paciente.getTipoDeIngresoAInternacion());

					boolean agregadoBaseDeDatos = false;
					int posicionBaseDeDatos = 0;

					while (posicionBaseDeDatos < this.baseDeDatos.length && !agregadoBaseDeDatos) {
						if (this.baseDeDatos[posicionBaseDeDatos] == null) {
							this.baseDeDatos[posicionBaseDeDatos] = this.pacientes[posicion];
							// nuevo
							this.baseDeDatos[posicionBaseDeDatos].setId(pacienteExisteBaseDeDatos.getId()); 
							agregadoBaseDeDatos = true;
						}
						posicionBaseDeDatos++;
					}
					agregado = true;
				}

				posicion++;
			}

		} else {

			while (posicion < this.pacientes.length && !agregado) {
				if (this.pacientes[posicion] == null) {
					this.pacientes[posicion] = paciente;
					this.pacientes[posicion].setId(Hospital.generarIdPaciente());

					boolean agregadoBaseDeDatos = false;
					int posicionBaseDeDatos = 0;

					while (posicionBaseDeDatos < this.baseDeDatos.length && !agregadoBaseDeDatos) {
						if (this.baseDeDatos[posicionBaseDeDatos] == null) {
							this.baseDeDatos[posicionBaseDeDatos] = this.pacientes[posicion];
							agregadoBaseDeDatos = true;
						}
						posicionBaseDeDatos++;
					}
					agregado = true;
				}

				posicion++;
			}

		}

		return agregado;
	}
	
	// INGRESA HISTORIAS CLINICAS SIEMPRE Y CUANDO EL PACIENTE SE ENCUENTRE INTERNADO //
		public boolean ingresarHistoriasClinicasHospital(HistoriaClinica historiasClinicas) {

			boolean agregado = false;
			int posicion = 0;

			while (posicion < this.historiasClinicas.length && !agregado) {
				if (this.historiasClinicas[posicion] == null) {
					this.historiasClinicas[posicion] = historiasClinicas;
					agregado = true;
				}

				posicion++;
			}

			return agregado;
		}
	
	// -----------------------------------------------------------------
	// -------------- DERIVAR Y ELIMINAR PACIENTE ----------------------
	// -----------------------------------------------------------------	

	// DERIVAR PACIENTE EN CONSULTORIO A INTERNACION Y SETEAR EL TIPO DE INGRESO A GUARDIA Y CAMBIAR CONSULTORIO A HABITACION //
	public boolean derivarPacienteAInternacion (long id) {
		boolean pacienteDerivado = false;
		boolean habitacionesLLenas = false;
		int posicion = 0;
		
		while(posicion < this.pacientes.length && !pacienteDerivado && !habitacionesLLenas) {
			if(this.pacientes[posicion] != null && this.pacientes[posicion].getId() == id) {
				if(this.cantidadPacientesInternados() == this.getCantidadHabitacionesParaInternacion()) {
					habitacionesLLenas = true;
				} else {
					this.pacientes[posicion].setTipoDeIngresoAInternacion(TipoDeIngresoAGuardia.INTERNACION);
					this.pacientes[posicion].setHabitacionOConsultorio(this.generarHabitacionAleatoria());
					pacienteDerivado = true;
				}
				
			}
			posicion++;
		}
		
		return pacienteDerivado;
	}

	// SE DARÁ DE ALTA AL PACIENTE, ELIMINANDO EL REGISTRO UNICAMENTE DEL ARRAY PACIENTES //
	public boolean darAltaPaciente(String dni) {
		boolean sePudoDarDeAltaPaciente = false;
		boolean pacienteIngresado = this.validarDniHospital(dni);

		if (pacienteIngresado) {
			boolean eliminado = false;
			int posicion = 0;

			while (posicion < this.pacientes.length && !eliminado) {
				if (this.pacientes[posicion] != null && this.pacientes[posicion].getDni().equals(dni)) {
					this.pacientes[posicion] = null;
					eliminado = true;
					sePudoDarDeAltaPaciente = true;
				}
				posicion++;
			}
		}

		return sePudoDarDeAltaPaciente;
	}

	// -----------------------------------------------------------------
	// ------------------------- OBTENER PACIENTE ----------------------
	// -----------------------------------------------------------------

	// TRAER PACIENTE DE LA BASE DE DATOS PARA OBTENER EL ID //
	public Paciente obtenerPacienteBaseDeDatos(String dni) {

		boolean econtrada = false;
		Paciente paciente = null;
		int posicion = 0;

		while (posicion < this.baseDeDatos.length && !econtrada) {
			if (this.baseDeDatos[posicion] != null && this.baseDeDatos[posicion].getDni().equals(dni)) {
				paciente = this.baseDeDatos[posicion];
				econtrada = true;
			}

			posicion++;
		}

		return paciente;
	}
	
	// TRAER PACIENTE DEL ARRAY PACIENTES //
	// // TRAER PACIENTE DEL ARRAY PACIENTES // //
	public Paciente obtenerPaciente(String dni) {
		Paciente paciente = null;
		int posicion = 0;
		boolean encontrada = false;
		
		while(posicion < this.pacientes.length && !encontrada) {
			if(this.pacientes[posicion] != null && this.pacientes[posicion].getDni().equals(dni)) {
				paciente = this.pacientes[posicion];
				encontrada = true;
			}
			posicion++;
		}
		
		return paciente;
	}

	// BUSCAR SI EXISTEN PACIENTES CON ESE MOTIVO DE INGRESO //
		public boolean buscarPacientesDeUnTipoDeDiagnstico(MotivoIngreso motivoIngreso) {
			boolean encontrado = false;
			int posicion = 0;

			while (posicion < this.pacientes.length && !encontrado) {
				if (this.pacientes[posicion] != null && this.pacientes[posicion].getMotivoIngreso().equals(motivoIngreso)) {
					encontrado = true;
				}
				posicion++;
			}

			return encontrado;
		}

	
	// -----------------------------------------------------------------
	// ------------------------- DEVOLVER ARRAY ------------------------
	// -----------------------------------------------------------------
	
	// TRAER HISTORIAS CLINICAS POR DNI //
		public HistoriaClinica[] obtnerHistoriasClinicasPorDni(String dni) {

			HistoriaClinica[] historiasClinicasObtenidosPorDni = new HistoriaClinica[this.historiasClinicas.length];
			int posicion = 0;

			for (int i = 0; i < historiasClinicas.length; i++) {
				if (this.historiasClinicas[i] != null && this.historiasClinicas[i].getDni().equals(dni)) {
					historiasClinicasObtenidosPorDni[posicion++] = this.historiasClinicas[i];
				}
			}

			return historiasClinicasObtenidosPorDni;
		}
	
		// TRAER PACIENTES EN GUARDIA ORDENDOS POR APELLIDO DE FORMA ASCENDENTE //
		public Paciente[] obtenerPacientesOrdenadosPorApellido() {

			Paciente[] pacientes = this.pacientes;
			Paciente aux;
			for (int i = 0; i < (this.pacientes.length - 1); i++) {
				for (int j = 0; j < (this.pacientes.length - i - 1); j++) {
					if (this.pacientes[j] != null && this.pacientes[j + 1] != null)
						if (this.pacientes[j].getApellido().compareTo(this.pacientes[j + 1].getApellido()) > 0) {
							{
								aux = this.pacientes[j];
								this.pacientes[j] = this.pacientes[j + 1];
								this.pacientes[j + 1] = aux;
							}
						}

				}
			}

			return pacientes;
		}
		
		// TRAER PACIENTES DE UN TIPO DE INTERNACION //
		public Paciente[] buscarPacientesDeUnTipoDeInternacion(TipoDeIngresoAGuardia internacion) {
			Paciente[] pacientes = new Paciente[this.pacientes.length];
			int posicion = 0;

			for (int i = 0; i < this.pacientes.length; i++) {
				if (this.pacientes[i] != null && this.pacientes[i].getTipoDeIngresoAInternacion().equals(internacion)) {
					pacientes[posicion++] = this.pacientes[i];
				}
			}

			return pacientes;
		}
		
		// TRAER PACIENTES TOTALES DE LA GUARDIA //
		public Paciente[] obtenerPacientesTotales() {
			Paciente[] pacientesObtenidos = new Paciente[this.pacientes.length];
			int posicion = 0;

			for (int i = 0; i < pacientes.length; i++) {
				if (this.pacientes[i] != null) {
					pacientesObtenidos[posicion++] = this.pacientes[i];
				}
			}

			return pacientesObtenidos;
		}
		
		// TRAER PACIENTES DE UN TIPO MOTIVO DE INGRESO //
		public Paciente[] obtenerPacientesDeUnTipoDeDiagnstico(MotivoIngreso motivoIngreso) {
			Paciente[] pacientesDeUnTipoDeDiagnstico = new Paciente[this.pacientes.length];
			int posicion = 0;

			for (int i = 0; i < this.pacientes.length; i++) {
				if (this.pacientes[i] != null && this.pacientes[i].getMotivoIngreso().equals(motivoIngreso)) {
					pacientesDeUnTipoDeDiagnstico[posicion++] = this.pacientes[i];
				}
			}

			return pacientesDeUnTipoDeDiagnstico;
		}
		
		// TRAER PACIENTES DE BASE DE DATOS POR ID //
		public Paciente[] obtenerBaseDeDatosPorID(long id) {
			Paciente[] pacientesPorId = new Paciente[this.baseDeDatos.length];
			int posicion = 0;

			for (int i = 0; i < this.baseDeDatos.length; i++) {
				if (this.baseDeDatos[i] != null && this.baseDeDatos[i].getId() == id) {
					pacientesPorId[posicion++] = this.baseDeDatos[i];
				}
			}

			return pacientesPorId;
		}
		
		// TRAER PACIENTES DE BASE DE DATOS POR FECHA DE INGRESO //
		public Paciente[] obtenerBaseDeDatosPorFechaDeIngreso(String fechaIngreso) {
			Paciente[] pacientesPorFechaIngreso = new Paciente[this.baseDeDatos.length];
			int posicion = 0;

			for (int i = 0; i < this.baseDeDatos.length; i++) {
				if (this.baseDeDatos[i] != null && this.baseDeDatos[i].getFechaIngreso().equals(fechaIngreso)) {
					pacientesPorFechaIngreso[posicion++] = this.baseDeDatos[i];
				}
			}

			return pacientesPorFechaIngreso;
		}

		// TRAER TODAS LAS HISTORIAS CLINICAS INGRESADAS //
		public HistoriaClinica[] obtenerHistoriasClinicasTotales() {
			HistoriaClinica[] historiasClinicasObtenidos = new HistoriaClinica[this.historiasClinicas.length];
			int posicion = 0;

			for (int i = 0; i < historiasClinicas.length; i++) {
				if (this.historiasClinicas[i] != null) {
					historiasClinicasObtenidos[posicion++] = this.historiasClinicas[i];
				}
			}

			return historiasClinicasObtenidos;
		}

		
	// -----------------------------------------------------------------
	// ------------------------- VALIDACIONES --------------------------
	// -----------------------------------------------------------------
	
	// VALIDACION SI HAY HABITACIONES DISPONIBLES // 
		public boolean validarHabitacionDisponible(int habitacion) {
			boolean encontrada = false;
			int posicion = 0;

			while (posicion < this.pacientes.length && !encontrada) {
				if (this.pacientes[posicion] != null && this.pacientes[posicion].getHabitacionOConsultorio() == habitacion) {
					encontrada = true;
				}

				posicion++;
			}

			return encontrada;
		}
		
		// VALIDACION SI HAY CONSULTORIOS DISPONIBLES // 
		public boolean validarConsultorionDisponible(int consultorio) {
			boolean encontrada = false;
			int posicion = 0;

			while (posicion < this.pacientes.length && !encontrada) {
				if (this.pacientes[posicion] != null && this.pacientes[posicion].getHabitacionOConsultorio() == consultorio) {
					encontrada = true;
				}

				posicion++;
			}

			return encontrada;
		}
		
		// VALIDAR SI EL PACIENTE SE ENCUENTRA EN EL HOSPITAL //
		public boolean validarDniHospital(String dni) {

			boolean encontrada = false;
			int posicion = 0;

			while (posicion < this.pacientes.length && !encontrada) {
				if (this.pacientes[posicion] != null && this.pacientes[posicion].getDni().equals(dni)) {
					encontrada = true;
				}

				posicion++;
			}

			return encontrada;
		}
		
		// VALIDAR DNI EN LA BASE DE DATOS //
		
		// VALIDAR DNI EN LA BASE DE BASE DE DATOS PARA NO REPETIR ID //
		public boolean validarDniBaseDeDatos(String dni) {

			boolean encontrada = false;
			int posicion = 0;

			while (posicion < this.baseDeDatos.length && !encontrada) {
				if (this.baseDeDatos[posicion] != null && this.baseDeDatos[posicion].getDni().equals(dni)) {
					encontrada = true;
				}

				posicion++;
			}

			return encontrada;
		}
	
		// VALIDAR PARA MOSTRAR MENSAJES //
		public boolean validarDniHistoriasClinicas(String dni) {

			boolean encontrada = false;
			int posicion = 0;

			while (posicion < this.historiasClinicas.length && !encontrada) {
				if (this.historiasClinicas[posicion] != null && this.historiasClinicas[posicion].getDni().equals(dni)) {
					encontrada = true;
				}

				posicion++;
			}

			return encontrada;
		}
		
		// -----------------------------------------------------------------
		// ------------------------- GENERAR HABIT/CONS --------------------
		// -----------------------------------------------------------------
		// GENERAR HABITACION ALEATORIA PARA PACIENTES EN INTERNACION //
		public int generarHabitacionAleatoria() {
			int minimo = 200;
			int maximo = this.getCantidadHabitacionesParaInternacion() + minimo;
			boolean valorExiste = false;
			int habitacionAleatoria;

			do {

				habitacionAleatoria = (int) (Math.random() * ((maximo - minimo) + 1)) + minimo;
				if (this.validarHabitacionDisponible(habitacionAleatoria)) {
					valorExiste = false;
				} else {
					valorExiste = true;
				}

			} while (!valorExiste);

			return habitacionAleatoria;
		}
		
		// GENERAR CONSULTORIO ALEATORIO //
		public int generarConsultorioAleatorio() {
			int minimo = 100;
			int maximo = this.getCantidadConsultorios() + minimo;
			boolean valorExiste = false;
			int habitacionAleatoria;

			do {

				habitacionAleatoria = (int) (Math.random() * ((maximo - minimo) + 1)) + minimo;
				if (this.validarHabitacionDisponible(habitacionAleatoria)) {
					valorExiste = false;
				} else {
					valorExiste = true;
				}

			} while (!valorExiste);

			return habitacionAleatoria;
		}
		
		// GENERAR ID_PACIENTE //
		public static long generarIdPaciente() {
			return ++idPaciente;
		}
		
		// -----------------------------------------------------------------
		// ------------------------------ CONTADOR -------------------------
		// -----------------------------------------------------------------

		// CONTAR HISTORIAS CLINICAS POR DNI (MOSTRAR MENSAJE///
		public int contadorHistoriasClinicasPorDni(String dni) {

			int vecesEncontrada = 0;
			int posicion = 0;

			while (posicion < this.historiasClinicas.length) {
				if (this.historiasClinicas[posicion] != null && this.historiasClinicas[posicion].getDni().equals(dni)) {
					vecesEncontrada++;
				}

				posicion += 1;
			}

			return vecesEncontrada;
		}
		
		// CONTAR PACIENTES PARA MOSTRAR MENSAJE SI NO EXISTEN AUN CON ESTE TIPO DE INTERNACION //
		public int contarPacientesPorTipoDeInternacion(TipoDeIngresoAGuardia internacion) {
			int pacientesEncontrados = 0;

			for (int i = 0; i < this.pacientes.length; i++) {
				if (this.pacientes[i] != null && this.pacientes[i].getTipoDeIngresoAInternacion().equals(internacion)) {
					pacientesEncontrados++;
				}
			}

			return pacientesEncontrados;
		}
		
		// CONTADOR DE PACIENTES INGRESADOS(MOSTRAR MENSAJES EN LA INTERFAZ DE HOSPITAL LLENO) //
		public int cantidadPacientesInternados() {

			int pacienteEncontrados = 0;
			int posicion;

			for (posicion = 0; posicion < pacientes.length; posicion++) {
				if (this.pacientes[posicion] != null && this.pacientes[posicion].getTipoDeIngresoAInternacion().equals(TipoDeIngresoAGuardia.INTERNACION)) {
					pacienteEncontrados += 1;
				}
			}

			return pacienteEncontrados;
		}
		
		// CONTADOR DE PACIENTES INGRESADOS(MOSTRAR MENSAJES EN LA INTERFAZ DE HOSPITAL LLENO) //
		public int cantidadPacientesEnConsulta() {

			int pacienteEncontrados = 0;
			int posicion;

			for (posicion = 0; posicion < pacientes.length; posicion++) {
				if (this.pacientes[posicion] != null && this.pacientes[posicion].getTipoDeIngresoAInternacion().equals(TipoDeIngresoAGuardia.CONSULTORIO)) {
					pacienteEncontrados += 1;
				}
			}

			return pacienteEncontrados;
		}
		
		// CONTAR HISTORIAS CLINICAS INGRESADAS PARA MOSTRAR MENSAJES //
		public int cantidadHistoriasClinicasIngresadas() {

			int historiasClinicasEncontrados = 0;
			int posicion;

			for (posicion = 0; posicion < historiasClinicas.length; posicion++) {
				if (this.historiasClinicas[posicion] != null) {
					historiasClinicasEncontrados += 1;
				}
			}

			return historiasClinicasEncontrados;
		}
		
		
	@Override
	public String toString() {
		return "Resumen del Hospital [cantidadPacientesInternados=" + cantidadPacientesInternados()
				+ ", cantidadPacientesEnConsulta=" + cantidadPacientesEnConsulta() + "]";
	}

}
