package ar.edu.unlam.pb1.dominio.enums;

public enum Diagnostico {
	
	DIABETES("Diabetes :"),
	HIPERTENSION_ARTERIAL("Hipertension Arterial :"),
	ACV("ACV :"),
	NEUMONIA("Neumonia :"),
	TRAUMATISMO("Traumatismo :");
	
	private String descripcion;
	
	Diagnostico(String descripcion) {
		this.descripcion = descripcion;	
	}
	
	public String getDescripcion() {
		return descripcion;
	}

}
