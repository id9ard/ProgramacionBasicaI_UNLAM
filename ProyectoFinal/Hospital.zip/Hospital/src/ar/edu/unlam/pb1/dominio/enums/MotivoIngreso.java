package ar.edu.unlam.pb1.dominio.enums;

public enum MotivoIngreso {
	DESMAYO("Desmayo :"),
	ACCIDENTE("Accidente :"),
	QUEMADURAS_GRAVES("Quemadura graves"),
	SOBREDOSIS("Sobredosis"),
	FIEBRES_Y_VOMITOS("Fiebres y vomitos :"),
	CONVULSIONES("Convulsiones :"),
	HEMORRAGIA("Hemorragia"),
	PERDIDA_DE_CONCIENCIA("Perdida de conciencia"),
	DIFICULTAD_PARA_RESPIRAR("Dificultad para respirar :"),
	TOS_PERSISTENTE("Tos persistente");
	
	private String descripcion;
	
	MotivoIngreso(String descripcion) {
		this.descripcion = descripcion;	
	}
	
	public String getDescripcion() {
		return descripcion;
	}
}
