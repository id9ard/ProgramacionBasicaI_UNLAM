package ar.edu.unlam.pb1.dominio.enums;

public enum ObraSocial {
	OSECAC("OSECAC :"),
	OSDE("OSDE :"),
	OSPRERA("OSPRERA :"),
	UOCRA("UOCRA"),
	UPCN("UPCN :");
	
	private String descripcion;
	
	ObraSocial(String descripcion) {
		this.descripcion = descripcion;	
	}
	
	public String getDescripcion() {
		return descripcion;
	}
}
