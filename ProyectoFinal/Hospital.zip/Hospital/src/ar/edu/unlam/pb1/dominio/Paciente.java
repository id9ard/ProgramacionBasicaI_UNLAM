package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.MotivoIngreso;
import ar.edu.unlam.pb1.dominio.enums.ObraSocial;
import ar.edu.unlam.pb1.dominio.enums.TipoDeIngresoAGuardia;

public class Paciente {

	private long id;
	private int habitacionOConsultorio;
	private int edad;
	
	private String nombre;
	private String apellido;
	private String dni;
	private String fechaIngreso;
	
	private ObraSocial obraSocial = null;
	private MotivoIngreso motivoIngreso = null;
	private TipoDeIngresoAGuardia tipoDeIngresoAInternacion;
	

	public Paciente(long id, int habitacionOConsultorio, String fechaIngreso, String nombre, String apellido, int edad, String dni,
			ObraSocial obraSocial, MotivoIngreso motivoIngreso, TipoDeIngresoAGuardia internacion) {
		this.id = Hospital.getIdPaciente();
		this.habitacionOConsultorio = habitacionOConsultorio;
		this.fechaIngreso = fechaIngreso;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.dni = dni;
		this.obraSocial = obraSocial;
		this.motivoIngreso = motivoIngreso;
		this.tipoDeIngresoAInternacion = internacion;
	}

	public TipoDeIngresoAGuardia getTipoDeIngresoAInternacion() {
		return tipoDeIngresoAInternacion;
	}

	public void setTipoDeIngresoAInternacion(TipoDeIngresoAGuardia tipoDeIngresoAInternacion) {
		this.tipoDeIngresoAInternacion = tipoDeIngresoAInternacion;
	}

	public String getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	public int getHabitacionOConsultorio() {
		return habitacionOConsultorio;
	}

	public void setHabitacionOConsultorio(int habitacionOConsultorio) {
		this.habitacionOConsultorio = habitacionOConsultorio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public ObraSocial getObraSocial() {
		return obraSocial;
	}

	public void setObraSocial(ObraSocial obraSocial) {
		this.obraSocial = obraSocial;
	}

	public MotivoIngreso getMotivoIngreso() {
		return motivoIngreso;
	}

	public void setMotivoIngreso(MotivoIngreso motivoIngreso) {
		this.motivoIngreso = motivoIngreso;
	}

	@Override
	public String toString() {
		return "Paciente [id=" + id + ", habitacion/consultorio=" + habitacionOConsultorio + ", nombre=" + nombre + ", apellido="
				+ apellido + ", edad=" + edad + ", dni=" + dni + ", obraSocial=" + obraSocial + ", motivoIngreso="
				+ motivoIngreso + ", internacion=" + tipoDeIngresoAInternacion + ", fechaIngreso=" + fechaIngreso + "]";
	}

}
