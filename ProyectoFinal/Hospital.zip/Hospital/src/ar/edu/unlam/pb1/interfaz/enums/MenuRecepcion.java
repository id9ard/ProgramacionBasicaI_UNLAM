package ar.edu.unlam.pb1.interfaz.enums;

public enum MenuRecepcion {
	INGRESAR_PACIENTES("Ingresar el paciente"),
	MOSTRAR_PACIENTES_ORDENADOS_POR_APELLIDO("Mostrar todos los pacientes pacientes ordenados por apellido"),
	MOSTRAR_POR_MOTIVO_DE_INGRESO("Mostrar pacientes de la guardia por motivo de Ingreso"),
	MOSTRAR_PACIENTES_INTERNADOS("Mostrar pacientes del hospital internados"),
	MOSTRAR_PACIENTES_EN_CONSULTA("Mostrar pacientes del hospital en consulta"),
	MOSTRAR_PACIENTES_POR_DNI("Mostrar paciente del hospital por Dni"),
	MOSTRAR_BASE_DE_DATOS_DEL_HOSPITAL("Mostrar registro total la base de datos del hospital"),
	MOSTRAR_BASE_DE_DATOS_DEL_HOSPITAL_POR_ID("Mostrar registros de la base de datos por Id"),
	MOSTRAR_PACIENTES_POR_FECHA_DE_INGRESO("Mostrar registros de la base de datos por Fecha de Ingreso"),
	SALIR("Volver al menu Principal");
	
	private String descripcion;
	
	MenuRecepcion(String descripcion) {
		this.descripcion = descripcion;	
	}
	
	public String getDescripcion() {
		return descripcion;
	}
}
