package ar.edu.unlam.pb1.interfaz.enums;

public enum MenuTrueFalse {
	VERDADERO("Verdadero"),
	FALSO("Falso");
	
	private String descripcion;
	
	MenuTrueFalse(String descripcion) {
		this.descripcion = descripcion;	
	}
	
	public String getDescripcion() {
		return descripcion;
	}
}
