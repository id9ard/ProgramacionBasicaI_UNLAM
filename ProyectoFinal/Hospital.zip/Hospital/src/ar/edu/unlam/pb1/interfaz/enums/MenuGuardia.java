package ar.edu.unlam.pb1.interfaz.enums;

public enum MenuGuardia {
	 RECEPCION("Ingrese al sistema de recepcion"),
	 MEDICO("Ingrese al sistema para doctores"),
	 SALIR("Cerrar Sistema");
	
	private String descripcion;
	
	MenuGuardia(String descripcion) {
		this.descripcion = descripcion;	
	}
	
	public String getDescripcion() {
		return descripcion;
	}
}
