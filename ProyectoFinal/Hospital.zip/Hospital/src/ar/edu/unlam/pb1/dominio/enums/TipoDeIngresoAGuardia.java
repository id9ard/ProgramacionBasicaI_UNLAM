package ar.edu.unlam.pb1.dominio.enums;

public enum TipoDeIngresoAGuardia {
	CONSULTORIO("Consultorio"),
	INTERNACION("Internacion");
	
	private String descripcion;
	
	TipoDeIngresoAGuardia(String descripcion) {
		this.descripcion = descripcion;	
	}
	
	public String getDescripcion() {
		return descripcion;
	}
}