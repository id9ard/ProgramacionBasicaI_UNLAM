package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.Diagnostico;
import ar.edu.unlam.pb1.interfaz.enums.MenuTrueFalse;

public class HistoriaClinica {

	private int frecuenciaCardiaca; // 55-220
	private int frecuenciaRespiratoria; // 8-25
	private int saturacionOxigeno; // 80-105
	private int glucemia; // 50-600
	private int temperatura; // 35-42
	
	private String dni;
	private String fechaHistoriaClinicaGenerada;
	
	private Diagnostico diagnostico = null;
	private MenuTrueFalse orientado = null;
	private MenuTrueFalse respuestaMotora = null;
	private MenuTrueFalse aperturaOcular = null;
	

	public HistoriaClinica(String dni, String fecha, Diagnostico diagnostico, int frecuenciaCardiaca,
			int frecuenciaRespiratoria, int saturacionOxigeno, int glucemia, int temperatura,
			MenuTrueFalse orientado, MenuTrueFalse respuestaMotora, MenuTrueFalse aperturaOcular) {
		this.dni = dni;
		this.fechaHistoriaClinicaGenerada = fecha;
		this.diagnostico = diagnostico;
		this.frecuenciaCardiaca = frecuenciaCardiaca; // 55-220
		this.frecuenciaRespiratoria = frecuenciaRespiratoria; // 8-25
		this.saturacionOxigeno = saturacionOxigeno; // 80-105
		this.glucemia = glucemia; // 50-600
		this.temperatura = temperatura; // 35-42
		this.orientado = orientado;
		this.respuestaMotora = respuestaMotora;
		this.aperturaOcular = aperturaOcular;

	}

	public String getFecha() {
		return fechaHistoriaClinicaGenerada;
	}

	public void setFecha(String fecha) {
		this.fechaHistoriaClinicaGenerada = fecha;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public Diagnostico getDiagnostico() {
		return diagnostico;
	}

	public void setDiagnostico(Diagnostico diagnostico) {
		this.diagnostico = diagnostico;
	}

	public int getFrecuenciaCardiaca() {
		return frecuenciaCardiaca;
	}

	public void setFrecuenciaCardiaca(int frecuenciaCardiaca) {
		this.frecuenciaCardiaca = frecuenciaCardiaca;
	}

	public int getFrecuenciaRespiratoria() {
		return frecuenciaRespiratoria;
	}

	public void setFrecuenciaRespiratoria(int frecuenciaRespiratoria) {
		this.frecuenciaRespiratoria = frecuenciaRespiratoria;
	}

	public int getSaturacionOxigeno() {
		return saturacionOxigeno;
	}

	public void setSaturacionOxigeno(int saturacionOxigeno) {
		this.saturacionOxigeno = saturacionOxigeno;
	}

	public int getGlucemia() {
		return glucemia;
	}

	public void setGlucemia(int glucemia) {
		this.glucemia = glucemia;
	}

	public double getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(int temperatura) {
		this.temperatura = temperatura;
	}

	public MenuTrueFalse getOrientado() {
		return orientado;
	}

	public void setOrientado(MenuTrueFalse orientado) {
		this.orientado = orientado;
	}

	public MenuTrueFalse getRespuestaMotora() {
		return respuestaMotora;
	}

	public void setRespuestaMotora(MenuTrueFalse respuestaMotora) {
		this.respuestaMotora = respuestaMotora;
	}

	public MenuTrueFalse getAperturaOcular() {
		return aperturaOcular;
	}

	public void setAperturaOcular(MenuTrueFalse aperturaOcular) {
		this.aperturaOcular = aperturaOcular;
	}

	@Override
	public String toString() {
		return "HistoriaClinica [dni=" + dni + ", fecha=" + fechaHistoriaClinicaGenerada + ", diagnostico=" + diagnostico
				+ ", frecuenciaCardiaca=" + frecuenciaCardiaca + ", frecuenciaRespiratoria=" + frecuenciaRespiratoria
				+ ", saturacionOxigeno=" + saturacionOxigeno + ", glucemia=" + glucemia + ", temperatura=" + temperatura
				+ ", orientado=" + orientado + ", respuestaMotora=" + respuestaMotora + ", aperturaOcular="
				+ aperturaOcular + "]";
	}

}
