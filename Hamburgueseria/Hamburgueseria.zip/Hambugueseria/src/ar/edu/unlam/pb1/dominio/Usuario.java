package ar.edu.unlam.pb1.dominio;

public class Usuario {

	private String contrasenia;
	
	public Usuario(String contrasenia) {
		this.contrasenia = contrasenia;
	}

	public String getContrasenia() {
		return contrasenia;
	}

}

