package ar.edu.unlam.pb1.interfaz;

import java.util.Scanner;

import ar.edu.unlam.pb1.dominio.Hamburguesa;
import ar.edu.unlam.pb1.dominio.Hamburgueseria;
import ar.edu.unlam.pb1.dominio.enums.TipoDePan;
import ar.edu.unlam.pb1.interfaz.enums.MenuPrincipal;

public class TestHamburgueseria {
	
	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		

		//---------------------------------------------------------------- //
		// --------------------- LOGICA DEL PROGRAMA --------------------- //
		//---------------------------------------------------------------- //
		
		Hamburgueseria hamburgueseria = new Hamburgueseria("Mi hamburgueseria", 4);
	
		boolean sesionValida = false;
		
		do {
			System.out.println("Ingrese contraseña :");
			String contrasenia = teclado.next();
			sesionValida = hamburgueseria.iniciarSesionAdmin(contrasenia);
		} while (!sesionValida);
		
		MenuPrincipal opcion = null;
		
		do {
			
			mostrarMenuPrincipal();
			opcion = ingresarOpcionDelMenu();
			
			switch(opcion) {
			
			case AGREGAR_HAMBURGUESA:
				
				Hamburguesa hamburguesa = ingresarHamburguesa();
				
				mostrarHamburguesaAgregada(hamburgueseria, hamburguesa);
				
				break;
			case MODIFICAR_HAMBURGUESA:
				break;
				
			case ELIMINAR_HAMBURGUESA:
				
				mostrarConfirmacionEliminado(hamburgueseria);
				
				break;
				
			case BUSCAR_HAMBURGUESA_POR_ID:
				
				mostrarHamburguesaPorId(hamburgueseria);
				
				break;
				
			case MOSTRAR_HAMBURGUESAS_DE_UN_TIPO_DE_PAN:
				
				mostrarHamburguesasDeUnTipoDePan(hamburgueseria);
				
				break;
				
			case MOSTRAR_LA_HAMBURGUESA_MAS_CARA:
				
				mostrarLaHamburguesaMasCara(hamburgueseria);
				
				break;
				
			case MOSTRAR_PROMEDIO_DE_PRECIO_HAMBURGUESAS_DE_UN_TIPO_DE_PAN:
				
				mostrarPromedioDePrecioHamburguesasDeUnTipoDePan(hamburgueseria);
				
				break;
				
			case MOSTRAR_PRECIO_TOTAL_HAMBURGUESAS:
				
				mostrarHamburguesasTotales(hamburgueseria);
				
				break;
			case SALIR:
				System.out.println("Gracias, vuelve pronto!");
				break;

			}
			
		} while (!opcion.equals(MenuPrincipal.SALIR));
		
	}

	//--------------------------------------------------------------------- //
	// --------------------- METODOS PARA EL PROGRAMA --------------------- //
	//--------------------------------------------------------------------- //

	// --------------------- MOSTRAR MENU PRINCIPAL ----------------------- //
	private static void mostrarMenuPrincipal() {
		for (MenuPrincipal menu : MenuPrincipal.values()) {
			System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
		}
	}
	
	private static MenuPrincipal ingresarOpcionDelMenu() {
		System.out.println("Ingrese una opcion:");
		return MenuPrincipal.values()[teclado.nextInt() - 1];
	}
	
	// --------------------- INGRESAR HAMBURGUESA ----------------------- //
	private static Hamburguesa ingresarHamburguesa() {
		System.out.println("Ingrese el precio de la hamburguesa: ");
		double precio = teclado.nextDouble();
		
		TipoDePan tipoDePan = ingresarTipoDePan();
		
		System.out.println("Es casera?");
		boolean casera = teclado.nextBoolean();
		
		System.out.println("Ingrese la cantida de patys");
		byte cantidadDePatys = teclado.nextByte();
		
		return new Hamburguesa(precio, tipoDePan, casera, cantidadDePatys);
	}
	
	private static void mostrarHamburguesaAgregada (Hamburgueseria hamburgueseria, Hamburguesa hamburguesa) {
		boolean agregada = hamburgueseria.agregarHamburguesa(hamburguesa);
		
		if (agregada) {
			System.out.println("\nHamburguesa agregada");
		} else {
			System.out.println("\nNo fue posible");
		}
	}
	
	// --------------------- INGRESAR TIPO DE PAN ----------------------- //
	private static TipoDePan ingresarTipoDePan() {
		mostrarTiposDePan();
		int opcionSeleccionada = teclado.nextInt() - 1;
		return TipoDePan.values()[opcionSeleccionada];
	}
	
	// --------------------- MOSTRAR TIPOS DE PAN ----------------------- //
	private static void mostrarTiposDePan() {
		System.out.println("Ingrese el tipo de pan :");
		for (TipoDePan menu : TipoDePan.values()) {
			System.out.println((menu.ordinal() + 1) + ". " + menu.getDescripcion());
		}
	}
	
	// --------------------- MOSTRAR HAMBURGUESAS ----------------------- //
	private static void mostrarHamburguesas(Hamburguesa[] hamburguesas) {
		for (int indice = 0; indice < hamburguesas.length; indice++) {
			if (hamburguesas[indice] != null) {
				System.out.println(hamburguesas[indice]);
			}
		}
	}
	
	private static void mostrarHamburguesasTotales(Hamburgueseria hamburgueseria) {
		mostrarHamburguesas(hamburgueseria.getHamburguesas());
	}
	
	// --------------------- BUSCAR HABURGUESA POR ID ----------------------- //
	private static void mostrarHamburguesaPorId(Hamburgueseria hamburgueseria) {
		System.out.println("Ingrese el id :");
		
		Hamburguesa hamburguesaObtenida = hamburgueseria.buscarPorID(teclado.nextLong());
		
		if (hamburguesaObtenida != null) {
			System.out.println(hamburguesaObtenida);
		} else {
			System.out.println("Hamburguesa no encontrada");
		}
	}
	
	// ------------------- MOSTRAR HAMBURGUESA POR TIPO DE PAN --------------------- //
	private static void mostrarConfirmacionEliminado(Hamburgueseria hamburgueseria) {
		System.out.println("Ingrese el id que desea eliminar");
		long id = teclado.nextLong();
		boolean eliminado = hamburgueseria.eliminarHamburguesa(id);
		
		if(eliminado) {
			System.out.println("Se pudo eliminar la hamburguesa");
		} else {
			System.out.println("No se puede eliminar");
		}
	}
	
	// ------------------- MOSTRAR HAMBURGUESA POR TIPO DE PAN --------------------- //
	private static void mostrarHamburguesasDeUnTipoDePan(Hamburgueseria hamburgueseria) {
		TipoDePan tipoDePan = ingresarTipoDePan();
		Hamburguesa[] hamburguesasObtenidas = hamburgueseria.obtenerHamburguesasDeunTipoDePan(tipoDePan);
		mostrarHamburguesas(hamburguesasObtenidas);
	}

	// --------------------- MOSTRAR HAMBURGUESA MAS CARA ----------------------- //
	private static void mostrarLaHamburguesaMasCara(Hamburgueseria hamburgueseria) {
		Hamburguesa hamburguesa = hamburgueseria.obtenerHamburguesaMasCara();
		if(hamburguesa != null) {
			System.out.println(hamburguesa);
		} else {
			System.out.println("No hay haburguesas");
		}
	}

	// ---------------- MOSTRAR PROMEDIO DE HAMBURGUESAS DE UN TIPO DE PAN ------------------ //
	private static void mostrarPromedioDePrecioHamburguesasDeUnTipoDePan(Hamburgueseria hamburgueseria) {
		TipoDePan tipoDePan = ingresarTipoDePan();
		double promedioDePrecio = hamburgueseria.obtenerPromedioDePrecioHamburguesasDeUnTipoDePan(tipoDePan);
		System.out.println("El promedio es : " + promedioDePrecio);
	}

}
