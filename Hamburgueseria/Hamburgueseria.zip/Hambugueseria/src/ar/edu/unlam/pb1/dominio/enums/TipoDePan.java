package ar.edu.unlam.pb1.dominio.enums;

public enum TipoDePan {
	CHIPA("Chipa"),
	PAPA("Papa"),
	FRANCES("Fránces");
	
	private String descripcion;
	
	TipoDePan(String descripcion) {
		this.descripcion = descripcion;	
	}
	
	public String getDescripcion() {
		return descripcion;
	}
}
