package ar.edu.unlam.pb1.interfaz.enums;

public enum MenuPrincipal {

	AGREGAR_HAMBURGUESA("Agregar Hamburguesa"), 
	MODIFICAR_HAMBURGUESA("Modificar Hamburguesa"),
	ELIMINAR_HAMBURGUESA("Eliminar Hamburguesa"), 
	BUSCAR_HAMBURGUESA_POR_ID("Buscar Hamburguesa por ID"),
	MOSTRAR_HAMBURGUESAS_DE_UN_TIPO_DE_PAN("Mostrar Haburguesas de un tipo de pan"),
	MOSTRAR_LA_HAMBURGUESA_MAS_CARA("Mostrar la hamburguesa mas cara"),
	MOSTRAR_PROMEDIO_DE_PRECIO_HAMBURGUESAS_DE_UN_TIPO_DE_PAN("Mostrar el promedio de Hamburguesas de un tipo de Pan"),
	MOSTRAR_PRECIO_TOTAL_HAMBURGUESAS("Mostrar precio total de Hamburguesas"),
	SALIR("Salir");

	private String descripcion;

	MenuPrincipal(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDescripcion() {
		return descripcion;
	}

}

