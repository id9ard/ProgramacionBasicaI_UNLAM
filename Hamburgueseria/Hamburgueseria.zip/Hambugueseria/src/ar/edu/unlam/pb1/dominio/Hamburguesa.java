package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.TipoDePan;

public class Hamburguesa {
	
	private long id;
	private double precio;
	private TipoDePan tipoDePan;
	private boolean casera;
	private byte cantidadDePatys;
	
	public Hamburguesa(double precio, TipoDePan tipoDePan, boolean casera, byte cantidadDePatys) {
		this.id = Hamburgueseria.obtenerSiguienteId();
		this.precio = precio;
		this.tipoDePan = tipoDePan;
		this.casera = casera;
		this.cantidadDePatys = cantidadDePatys;
	}

	public long getId() {
		return id;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public TipoDePan getTipoDePan() {
		return tipoDePan;
	}

	public void setTipoDePan(TipoDePan tipoDePan) {
		this.tipoDePan = tipoDePan;
	}

	public boolean isCasera() {
		return casera;
	}

	public void setCasera(boolean casero) {
		this.casera = casero;
	}

	public byte getCantidadDePatys() {
		return cantidadDePatys;
	}

	public void setCantidadDePatys(byte cantidadDePatys) {
		this.cantidadDePatys = cantidadDePatys;
	}

	@Override
	public String toString() {
		return "Hamburguesa [id=" + id + ", precio=" + precio + ", tipoDePan=" + tipoDePan + ", casero=" + casera
				+ ", cantidadDePatys=" + cantidadDePatys + "]";
	}
	
}
