package ar.edu.unlam.pb1.dominio;

import ar.edu.unlam.pb1.dominio.enums.TipoDePan;

public class Hamburgueseria {
	
	private static final String CONTRASENIA_ADMIN = "LouisAdmin";
	private static final String CONTRASENIA = "Louis";
	private static long proximoId = 0;
	private String nombre;
	private Usuario usuario;
	private Usuario usuario2;
	private Hamburguesa[] hamburguesas;
	
	public Hamburgueseria(String nombre, int cantidadDeHamburguesas) {
		this.nombre = nombre;
		this.hamburguesas = new Hamburguesa[cantidadDeHamburguesas];
		this.usuario = new Usuario(CONTRASENIA);
		this.usuario2 = new Usuario(CONTRASENIA_ADMIN);
	}
	
	public boolean iniciarSesion(String contrasenia) { 
		return usuario.getContrasenia().equals(contrasenia);
	}

	public boolean iniciarSesionAdmin(String contrasenia) {
		return usuario2.getContrasenia().equals(contrasenia);
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Hamburguesa[] getHamburguesas() {
		return hamburguesas;
	}

	public void setHamburguesas(Hamburguesa[] hamburguesas) {
		this.hamburguesas = hamburguesas;
	}
	
	public static long obtenerSiguienteId() {
		return ++proximoId;
	}
	
	/*public boolean agregarHamburguesa(Hamburguesa hamburguesa) {
		boolean agregada = false;
		int posicion = 0;
		
		while(posicion < this.hamburguesas.length && !agregada) {
			if (this.hamburguesas[posicion] == null) {
				this.hamburguesas[posicion] = hamburguesa;
				agregada = true;
			}
			posicion++;
		}
		return agregada;
	}*/
	
	public Hamburguesa buscarPorID(long id) {
		Hamburguesa hamburguesa = null;
		boolean encontrada = false;
		int posicion = 0;
		
		while(posicion < this.hamburguesas.length && !encontrada) {
			if (this.hamburguesas[posicion] != null && this.hamburguesas[posicion].getId() == id) {
				hamburguesa = this.hamburguesas[posicion];
				encontrada = true;
			}
		
			posicion++;
		}
		
		return hamburguesa;
	}
	
	public double obtenerPromedioDePrecioHamburguesasDeUnTipoDePan(TipoDePan tipoDePan) { 
		double promedio = 0; 
		double preciosAcumulados = 0; 
		int cantidadDeHamburguesasDelTipoDePan = 0; 
		
		for (int i = 0; i < hamburguesas.length; i++) { 
			
			if (this.hamburguesas[i] != null && this.hamburguesas[i].getTipoDePan().equals(tipoDePan)) { 
				preciosAcumulados += this.hamburguesas[i].getPrecio(); 
				cantidadDeHamburguesasDelTipoDePan++;
			}
		}
		
		if (cantidadDeHamburguesasDelTipoDePan > 0) {
			promedio = preciosAcumulados / cantidadDeHamburguesasDelTipoDePan;
		}
		
		return promedio;
	}
	
	public Hamburguesa[] obtenerHamburguesasDeunTipoDePan(TipoDePan  tipoDePan) { 
		Hamburguesa[] hamburguesasObtenidas = new Hamburguesa[this.hamburguesas.length];
		int posicion = 0;  
		
		for (int i = 0; i < hamburguesas.length; i++) {
			if (this.hamburguesas[i] != null && this.hamburguesas[i].getTipoDePan().equals(tipoDePan)) {
				hamburguesasObtenidas[posicion++] = this.hamburguesas[i];
			}
		}
		
		return hamburguesasObtenidas;
	}
	
	/*public Hamburguesa[] obtenerHamburguesasTotales() { 
		Hamburguesa[] hamburguesasObtenidas = new Hamburguesa[this.hamburguesas.length];
		int posicion = 0;  
		
		for (int i = 0; i < hamburguesas.length; i++) {
			if (this.hamburguesas[i] != null) {
				hamburguesasObtenidas[posicion++] = this.hamburguesas[i];
			}
		}
		return hamburguesasObtenidas;
	}*/
	
	public Hamburguesa obtenerHamburguesaMasCara() {
		
		Hamburguesa hamburguesaMasCara = null;
		
		for (int i = 0; i < hamburguesas.length; i++) {
			
			if (this.hamburguesas[i] != null &&
					//null									100										50
					(hamburguesaMasCara == null || this.hamburguesas[i].getPrecio() > hamburguesaMasCara.getPrecio())) {
				
				hamburguesaMasCara = this.hamburguesas[i];
			}
		}
		
		return hamburguesaMasCara;
	}
	
	public boolean agregarHamburguesa(Hamburguesa hamburguesa) {
		boolean agregado = false;
		int posicion = 0;
		
		while(posicion < this.hamburguesas.length && !agregado) {
			if(this.hamburguesas[posicion] == null) {
				this.hamburguesas[posicion] = hamburguesa;
				agregado = true;
			}
			posicion++;
		}
		
		return agregado;
	}
	
	public boolean eliminarHamburguesa (long id) {
		boolean eliminada = false;
		int posicion = 0;
		
		while(posicion < this.hamburguesas.length && !eliminada) {
			if(this.hamburguesas[posicion] != null && hamburguesas[posicion].getId() == id) {
				hamburguesas[posicion] = null;
				eliminada = true;
			}
			posicion++;
		}
		
		return eliminada;
	}
	
	/*boolean esValido = false;
 
		if (correo.contains("@") && correo.endsWith(".com")) {
			esValido = true;
		}
 
		return esValido;*/
}
